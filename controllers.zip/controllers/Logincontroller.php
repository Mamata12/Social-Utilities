<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logincontroller extends CI_Controller {
	
	public function _construct(){
		parent::_construct();
		$this->load->helper('url');
	}
	
	public function index()
	{
		$this->load->library('facebook');
		
		$appId = '891978440912957'; //Facebook App ID
		$appSecret = 'd4e4c95d7b27de4d7db78ead9fd63a23'; // Facebook App Secret
		$homeurl = 'http://localhost/social_utilities/';  //return to home
		$fbPermissions = 'email';  //Required facebook permissions

			//Call Facebook API
			$facebook = new Facebook(array(
			  'appId'  => $appId,
			  'secret' => $appSecret

			));
		$fbuser = $facebook->getUser();
	}
}
