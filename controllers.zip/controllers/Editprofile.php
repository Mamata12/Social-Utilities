<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Editprofile extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Model_session');
    }

    public function index() {
         $verify = $_GET['userid'];
      
		 $this->db->select()->from('user_ragister')->where('id', $verify);
         $query = $this->db->get();
	 
         $data['profile']= $query->first_row('array');
         $this->load->view('editprofile',$data);
         //echo $data;
        
    }
    
   public function edit(){
    	$name=$_POST['name'];
		$email=$_POST['email'];
		$contact=$_POST['contact'];
		$pass=$_POST['pass'];
		$id=$_POST['id'];
		
$result_set = $this->db->query("UPDATE user_ragister SET fullname = '$name' , email = '$email' , mobile = '$contact' , password = '$pass' WHERE id = '$id'");
		  echo $result_set;
		
		//$this->load->model('Register_model');
		//$verify = $this->Register_model->edit_profile_model();
		//echo $verify;
	}
    
    

}
