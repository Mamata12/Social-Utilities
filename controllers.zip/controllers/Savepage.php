<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Savepage extends CI_Controller {
	
 public function index(){

$random = rand(100, 1000);

//$_POST[data][1] has the base64 encrypted binary codes. 
//convert the binary to image using file_put_contents
$savefile = @file_put_contents("output/$random.png", base64_decode(explode(",", $_POST['data'])[1]));

//if the file saved properly, print the file name
if($savefile){
	echo $random;
}
}
}
