<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Resetpass extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Model_session');
    }

    public function index() {
        $data["email"] = base64_decode($_GET['email']);
        $this->load->view('resetpass', $data);
        
    }
    
    public function reset_pass(){
    	//$cpass=$_POST['cpass'];
		//$email=$_POST['email'];
		$this->load->model('Register_model');
		$verify = $this->Register_model->reset_pass_model();
		echo $verify;
	}
    

}
