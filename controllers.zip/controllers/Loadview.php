<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Loadview extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Model_session');
    }

    public function index() {
      $this->load->view("index");
    }
     public function dedicate() {
      $this->load->view("indexdedication");
    }
    /*public function fbfunsinglepage() {
      $this->load->view("fbfunresultpage");
    }*/
     public function fbfunsinglepage1() {
     	$verify = $_GET['random'];
        $this->load->view('fbfunresultpage',$verify);
      //$this->load->view("fbfunresultpage");
    }
    
   
}
