<?php

class Logout extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('Model_session');
              
	}
	
	function index()
	{
		//if(isset($_POST['logout'])){
			$this->Model_session->logout();
                        redirect('');
			
		
                        
		//}
		
		
	}
	
	
	
}

/* End of file welcome.php */
/* Location: ./system/application/controllers/welcome.php */