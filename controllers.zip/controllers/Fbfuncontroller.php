<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Fbfuncontroller extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Model_session');
    }

    public function index() {
      $this->load->view("fbfun");
    }
    
  
}
