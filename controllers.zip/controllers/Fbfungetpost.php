<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Fbfungetpost extends CI_Controller {

    function __construct() {
        parent::__construct();

        $this->load->model('Model_session');
    }
     public function GetFBPost() {
		$GetUrlID = $_POST['GetUrlID'];
       
		$result_set = $this->db->query("SELECT * FROM facebook_fun WHERE tid = '$GetUrlID' ORDER BY RAND() LIMIT 1");
        foreach ($result_set->result() as $row) {
            $entries[] = $row;
        }
        $data = array(
            'Rows' => $entries
        );
        $this->output->set_content_type('application/json');
        echo json_encode(array($data));
//echo $GetUrlID;
        exit;
    }
    
}
?>