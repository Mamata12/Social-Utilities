<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Changepass extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Model_session');
    }

    public function index() {
        //$data["id"] = $_POST['id'];
         $verify = $_GET['userid'];
      
		 $this->db->select()->from('user_ragister')->where('id', $verify);
         $query = $this->db->get();
	 
         $data['profile']= $query->first_row('array');
        $this->load->view('changepassword',$data);
        
    }
    
    public function reset_pass(){
    	$cpass=$_POST['cpass'];
		$id=$_POST['id'];
		$this->load->model('Register_model');
		$verify = $this->Register_model->change_pass_model();
		echo $verify;
	}
    

}
