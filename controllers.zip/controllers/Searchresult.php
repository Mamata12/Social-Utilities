<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Searchresult extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Model_session');
    }

    public function index() {
    	$data['searchdata'] = $_GET['searchdata'];
		$this->load->view('searchresult',$data);
    }
    
    public function searchresultpage(){
    	 $m=$_POST['myValue'];
    	
		//$this->load->model('Register_model');
		//$result_set = $this->Register_model->searchdata($m);
       // $result_set = $this->db->query("SELECT * FROM user_post where (Dadicatorname LIKE '%'".$m."'%')");
        $result_set = $this->db->query("SELECT * FROM user_post where (Dadicatorname LIKE '%'".$m."'%' or Dadicateename LIKE '%'".$m."'%' or Dadicator_email_id LIKE '%'".$m."'%' or Dadicatee_email_id LIKE '%'".$m."'%' or Dedication_item_type LIKE '%'".$m."'%' or Dedication_title LIKE '%'".$m."'%' or Dedication_item LIKE '%'".$m."'%' or Dedication_message LIKE '%'".$m."'%')");
        $total_set = $result_set->num_rows();
          if ($total_set > 0) {
        foreach ($result_set->result() as $row) {
                $entries[] = $row;
            }
            $data = array(
                'Rows' => $entries
            );
            $this->output->set_content_type('application/json');
            echo json_encode(array($data));
          
        } else {

            $data = "";
            echo json_encode(array($data));
        }

        exit;
	}
}
