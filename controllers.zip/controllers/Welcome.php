<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    function __construct() {
        parent::__construct();

        $this->load->model('Model_session');
        $this->load->helper('url');
        $this->load->library('facebook', array('appId' => '891978440912957', 'secret' => 'd4e4c95d7b27de4d7db78ead9fd63a23'));

		// Get user's login information
		$this->user = $this->facebook->getUser();
    }
    
public function index() {
    	
if ($this->user) {

$data['user_profile'] = $this->facebook->api('/me/');

// Get logout url of facebook
if(isset($_GET['logout'])){
    if($_GET['logout']=='yes'){
     	$redir_url='http://'.$_SERVER['SERVER_NAME'].'/social_utilities';
	$logoutUrl = $this->facebook->getLogoutUrl(array('next'=>$redir_url));
        session_destroy();
	header('location:'.$logoutUrl);     
    }
}
// Send data to profile page
$this->load->view('index', $data);
$this->load->view('fbheader');
} else {

// Store users facebook login url
$data['login_url'] = $this->facebook->getLoginUrl();
$this->load->view('index', $data);
$this->load->view('header');
}

      		//$this->load->view("index");
}
 
    

public function forgot_pass_check(){			
	        $this->load->model('Register_model');
            $verify = $this->Register_model->forgot_pass();
            if ($verify) {
               
                $var=$this->reset_pass_sent($verify);   
                 echo $var;     
            } elseif ($verify == "0") {
                 echo "0";
                 $this->session->set_flashdata('fail', "Email Mismatch");
            	 $this->session->keep_flashdata('fail');
            	 echo $this->session->flashdata('fail');
            } else {
                 echo "2";
            }
}


public function reset_pass_sent($verify){
	
			$to = $verify;
        	$encrypted_email = base64_encode($to);
       		$link = base_url() . "index.php/resetpass?email=" . $encrypted_email .""; //return $link;
        
 			$email_msg = "Dear User, <p--> To change your password, please follow this link, or copy and paste it into your browser's address bar: If you do not wish to change your password, just ignore this message.<p></p>";
            $email_msg .="<a href=$link> Click Here To Reset Password </a>";
            $email_msg .= "<p>Thanks, Support Team</p>";
            $subject = "Password Recovery Mail";
            $this->load->library('email');
            $config['charset'] = 'iso-8859-1';
            $config['wordwrap'] = TRUE;
            $config['mailtype'] = 'html';
            $this->email->initialize($config);
            $this->email->from('shridhar@whitecode.co.in', 'Support Team Social Utilities');
            $this->email->to($to);
            $this->email->subject($subject);
            $this->email->message($email_msg);
            if ($this->email->send()) {
                echo "Please check your email to Reset Password";
               
            } else {
                echo "Some thing went wrong.Please contact server administration";
            }

}


public function delete_post(){
	 $id = $_POST['id'];
	 echo json_encode($id);
	  $this->db->delete('user_post', array('id' => $id));
	//echo $id;
}

public function reset_pass(){
	
     return "1";
	
}

public function GetSearchData(){

            $search=$_POST['name_startsWith'];
             $this->db->select("*");
             $this->db->like('Dadicatorname', $search);
			 $this->db->or_like('Dadicator_email_id', $search); 
			 $this->db->or_like('Dadicateename', $search); 
			 $this->db->or_like('Dadicatee_email_id', $search); 
			 $this->db->or_like('Dedication_title', $search); 
			 $this->db->or_like('Dedication_item', $search); 
			 $this->db->or_like('Dedication_City', $search); 
			 $this->db->or_like('Dedication_item_type', $search); 
			 $this->db->or_like('Dedication_message', $search); 
			 $this->db->or_like('Dedication_Theme', $search); 
			 
			   
			$query = $this->db->get('user_post',6);
               $data = array();
if ( $query->num_rows() > 0 )
{
               foreach($query->result() as $row){
                $Dadicatorname=$row->Dadicatorname;
                $Dedication_title=$row->Dedication_title;
                $Dadicator_email_id=$row->Dadicator_email_id;
                $Dadicateename=$row->Dadicateename;
                $Dadicatee_email_id=$row->Dadicatee_email_id;
                $Dedication_item_type=$row->Dedication_item_type;
                $Dedication_message	=$row->Dedication_message;
                   $id=$row->id;
                  // $name=$layout_type ." Dedicated  ". $layout_title." | ".$id;
                  $name=$Dadicatorname ." Dedicated  ". $Dedication_title." | ".$id;
                   array_push($data, $name);
                  
               }
              
}else{
                   $layout_type="Sorry Searching Data Not Found";
                   $layout_title="";
                   $id="0";
                   $name=$layout_type." | ".$id;
                   array_push($data, $name);
}
               // print_r($data);
		echo json_encode($data);
      
}



    
    public function Singlepage() {
        $verify = $_GET['random'];
        $this->load->view('singlePost',$verify);
    }

    public function register_database() {
        $to = $_POST['email'];
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('email', 'Email', 'required|is_unique[user_ragister.email]');
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('fail', "Email already register/Password Mismatch");
            $this->session->keep_flashdata('fail');
            echo $this->session->flashdata('fail');
        } else {
            $random = rand();
            $this->load->model('Register_model');
            $this->Register_model->register($random);
            $email_msg = "Dear User, <p--> Please click on below URL or paste into your browser to verify your Email Address.<p></p>";
            $email_msg .="<a href=http://whitecode.in/demo/social_utilities/index.php/Welcome/verify?random=$random>Click here</a>";
            $email_msg .= "<p>Thanks, Support Team</p>";
            $subject = "Email Verification";
            $this->load->library('email');
            $config['charset'] = 'iso-8859-1';
            $config['wordwrap'] = TRUE;
            $config['mailtype'] = 'html';
            $this->email->initialize($config);
            $this->email->from('shridhar@whitecode.co.in', 'Support Team');
            $this->email->to($to);
            $this->email->subject($subject);
            $this->email->message($email_msg);
            if ($this->email->send()) {
                echo "please varify through your email  for activation";
            } else {
                echo "Some thing went wrong.Please contact server administration";
            }
        }
    }

    public function Shearthought() {       
        $this->load->model('Register_model');
        $last_id = $this->Register_model->InserPost();
        echo $last_id;
    }

    public function GetPost() {

        $result_set = $this->db->query("SELECT * FROM user_post order by id DESC LIMIT 5");
        foreach ($result_set->result() as $row) {
            $entries[] = $row;
        }
        $data = array(
            'Rows' => $entries
        );
        $this->output->set_content_type('application/json');
        echo json_encode(array($data));

        exit;
    }
    public function GetTrends() {

        $result_set = $this->db->query("SELECT * FROM trends order by tid DESC");//changed here query not yet update online 
        foreach ($result_set->result() as $row) {
            $entries[] = $row;
        }
        $data = array(
            'Rows' => $entries
        );
        $this->output->set_content_type('application/json');
        echo json_encode(array($data));

        exit;
    }
    
    public function GetProfilePost() {
        $LoggedUserEmail = $this->Model_session->getUserEmail();
        $result_set = $this->db->query("SELECT * FROM user_post where (Dadicator_email_id='$LoggedUserEmail' or Dadicatee_email_id='$LoggedUserEmail') order by id DESC LIMIT 5");
        foreach ($result_set->result() as $row) {
            $entries[] = $row;
        }
        $data = array(
            'Rows' => $entries
        );
        $this->output->set_content_type('application/json');
        echo json_encode(array($data));

        exit;
    }
    
    public function GetPostSinglePost() {
        $GetUrlID = $_POST['GetUrlID'];
        $result_set = $this->db->query("SELECT * FROM user_post where id='$GetUrlID' ");
       
        $total_set = $result_set->num_rows();
          if ($total_set > 0) {
        foreach ($result_set->result() as $row) {
                $entries[] = $row;
            }
            $data = array(
                'Rows' => $entries
            );
            $this->output->set_content_type('application/json');
            echo json_encode(array($data));
          
        } else {

            $data = "";
            echo json_encode(array($data));
        }

        exit;
	}
	

    public function LoadMoreProfilePost() {
        $lastPostID = $_POST['lastPostID'];
        $LoggedUserEmail = $this->Model_session->getUserEmail();
//        $result_set = $this->db->query("SELECT *,  IFNULL(like_count,0) AS New_like_count FROM layouts L inner join user U on L.UploaderId=U.userid Left outer join viewlikes V on V.postID = L.id where L.id<'$lastPostID' order by L.id DESC LIMIT 5");
        $result_set = $this->db->query("SELECT * FROM user_post  where id<'$lastPostID' and (Dadicator_email_id='$LoggedUserEmail' or Dadicatee_email_id='$LoggedUserEmail') order by id DESC LIMIT 5");
        $total_set = $result_set->num_rows();
        if ($total_set > 0) {
            foreach ($result_set->result() as $row) {
                $entries[] = $row;
            }
            $data = array(
                'Rows' => $entries
            );
            $this->output->set_content_type('application/json');
            echo json_encode(array($data));
        } else {

            $data = "";
            echo json_encode(array($data));
        }

        exit;
    }
    
    public function LoadMorePost() {
        $lastPostID = $_POST['lastPostID'];

//        $result_set = $this->db->query("SELECT *,  IFNULL(like_count,0) AS New_like_count FROM layouts L inner join user U on L.UploaderId=U.userid Left outer join viewlikes V on V.postID = L.id where L.id<'$lastPostID' order by L.id DESC LIMIT 5");
        $result_set = $this->db->query("SELECT * FROM user_post  where id<'$lastPostID' order by id DESC LIMIT 5");
        $total_set = $result_set->num_rows();
        if ($total_set > 0) {
            foreach ($result_set->result() as $row) {
                $entries[] = $row;
            }
            $data = array(
                'Rows' => $entries
            );
            $this->output->set_content_type('application/json');
            echo json_encode(array($data));
        } else {

            $data = "";
            echo json_encode(array($data));
        }

        exit;
    }

    public function login_check() {

        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('pass', 'Password', 'required');
        if ($this->form_validation->run() == FALSE) {
            echo "-1";
        } else {

            $this->load->model('Register_model');
            $verify = $this->Register_model->login();
            if ($verify == "1") {
                echo "1";
            } elseif ($verify == "0") {
                echo "0";
            } else {
                echo "2";
            }
            // redirect(base_url(), 'refresh'); 
            
        }
    }

//login

    public function verify() {
        $verify = $_GET['random'];
        $this->load->model('Register_model');
        $noOfRecords = $this->Register_model->verify($verify);
        if ($noOfRecords > 0) {
            $this->session->set_flashdata('success', "Email Verified Successfully!.");
            $this->session->keep_flashdata('success');
            redirect('http://whitecode.in/demo/social_utilities');
        } else {
            $this->session->set_flashdata('success', "Sorry! Unable to verify your email. Please try again.");
            redirect('http://whitecode.in/demo/social_utilities');
        }
    }

}
