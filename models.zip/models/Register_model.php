<?php

class Register_model extends CI_Model {

    function __construct() {
        parent::__construct();

        $this->load->model('Model_session');
    }


public function edit_profile_model(){
	     $this->name=$_POST['name'];
		 $this->email=$_POST['email'];
		 $this->contact=$_POST['contact'];
		 $this->pass=$_POST['pass'];
		 $this->id=$_POST['id'];
		 
		 $this->db->update('user_ragister', $this);
}




public function searchdata($m){
	 // $search =trim($_POST['myValue']);
	 // $sdata=$_POST['myValue'];
	   //$m="mamata";
	   //$m=$_POST['myValue'];
	   $data=$m;
	  // $result_set = $this->db->query("SELECT * FROM user_post where (Dadicatorname LIKE '%'".$sdata."'%' or Dadicator_email_id LIKE '%'".$sdata."'%' or Dadicatee_email_id LIKE '%'".$sdata."'%' or Dadicateename LIKE '%'".$sdata."'%' or Dedication_item_type LIKE '%'".$sdata."'%' or Dedication_title LIKE '%'".$sdata."'%' or Dedication_City LIKE '%'".$sdata."'%' or Dedication_item LIKE '%'".$sdata."'%'  or Dedication_message LIKE '%'".$sdata."'%')");
       
	// $result_set = $this->db->query("SELECT * FROM user_post where (Dadicatorname LIKE '%'".$sdata."'%' or Dadicator_email_id LIKE '%'".$sdata."'%' or Dadicateename LIKE '%'".$sdata."'%' or Dadicatee_email_id LIKE '%'".$sdata."'%' or Dedication_item_type LIKE '%'".$sdata."'%' or Dedication_title LIKE '%'".$sdata."'%' or Dedication_City LIKE '%'".$sdata."'%' or Dedication_item LIKE '%'".$sdata."'%'  or Dedication_message  LIKE '%'".$sdata."'%')");
	
	$result_set = $this->db->query("SELECT * FROM user_post where (Dadicatorname LIKE '%".$data."%')");
	
	  return $result_set;
}

public function change_pass_model(){
	
    $result=$this->db->set('password', $_POST['cpass'])->where('id',  $_POST['id'])->update('user_ragister');
    return $result;
  // return $email;
}
public function reset_pass_model(){
	
    $m= trim($_POST['email']);
    $result=$this->db->set('password', $_POST['cpass'])->where('email',  $m)->update('user_ragister');
    return $result;
  // return $email;
}
 
 public function forgot_pass() {
        $email = $_POST['fpemail'];
        $query=$this->db->get_where('user_ragister',array('email'=>$email));
        $count = $query->num_rows() > 0;
        if ($count==1) {
       			 foreach ($query->result() as $row) {
                    $email = $row->email;
                    return "$email";
            }
            }else{
                 return "0";                 
            }
            
}


   public function register($random) {

        $this->created_date = date("Y-m-d");
        $this->fullname = $_POST['fullname'];       
        $this->mobile = $_POST['mno'];
        $this->email = $_POST['email'];
        $this->password = $_POST['pass'];
        $this->random = $random;
        $this->is_active = "0";

        $this->db->insert('user_ragister', $this);
    }
    
    public function InserPost() {
		$Dadicatorname = $_POST['Dadicatorname'];
        $Dadicator_email_id = $_POST['Dadicator_email_id'];
        $Dadicateename = $_POST['Dadicateename'];
        $Dadicatee_email_id = $_POST['Dadicatee_email_id'];
        $Dedication_item_type = $_POST['Dedication_item_type'];
        $Dedication_title = $_POST['Dedication_title'];
        $Dedication_City = $_POST['Dedication_City'];
        $Dedication_item = $_POST['Dedication_item'];
        $Dedication_message = $_POST['Dedication_message'];
        
        $ShowPageViewCount = $_POST['ShowPageViewCount'];
        
        $this->post_date = date("Y-m-d");
        $this->Dadicatorname = $_POST['Dadicatorname'];       
        $this->Dadicator_email_id = $_POST['Dadicator_email_id'];
        $this->Dadicateename = $_POST['Dadicateename'];
        $this->Dadicatee_email_id = $_POST['Dadicatee_email_id'];
        
         $this->Dedication_item_type = $_POST['Dedication_item_type'];       
        $this->Dedication_title = $_POST['Dedication_title'];
        $this->Dedication_City = $_POST['Dedication_City'];
        $this->Dedication_item = $_POST['Dedication_item'];
        
         $this->Dedication_message = $_POST['Dedication_message'];       
        
        
        $ShowPageViewCount = $_POST['ShowPageViewCount'];
        if((int) $ShowPageViewCount == 1){
             $ShowPageViewCount="1";
        }else{
            $ShowPageViewCount="0";
        }
        $ShowComments = $_POST['ShowComments'];
        if((int) $ShowComments == 1){
             $ShowComments="1";
        }else{
            $ShowComments="0";
        }        
        $this->ShowPageViewCount = $ShowPageViewCount;
        $this->ShowComments = $ShowComments;       
        $this->db->insert('user_post', $this);
        $this->db->trans_complete();
        echo $this->db->insert_id();
    }

//register

    public function login() {

        $username = $_POST['username'];
        $password = $_POST['pass'];
        $query = $this->db->get_where('user_ragister', array('email' => $username, 'password' => $password));
        $count = $query->num_rows() > 0;
        if ($count == 1) {
            $query1 = $this->db->get_where('user_ragister', array('email' => $username,'is_active' => 1));
            if ($query1->num_rows() > 0) {
                foreach ($query1->result() as $row) {
                	$username1 = $row->fullname;
                    $email = $row->email;
                    $id = $row->id;
                }
                 $this->Model_session->set_session($email);
                 $this->Model_session->set_session_name($username1);
                 $this->Model_session->set_session_id($id);
                 
              return "1";
            }else{
                 return "0";
            }
           
        } else {
            return "2";
        }
        
   
  }
//login

    public function verify($random) {
        $this->db->set('is_active', 1)
                ->where('random', $random)
                ->update('user_ragister');
        return $this->db->affected_rows();
    }

//verify
}

//model
?>