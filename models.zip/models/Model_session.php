<?php
class Model_session extends CI_Model {
    function __construct()
    {
        parent::__construct();
          
    }
    
   function set_session_name($username1){
   	   $this->session->set_userdata('logged_user_name', $username1);
   } 
   function set_session($email){
   	   $this->session->set_userdata('logged_user', $email);
   }
   function set_session_id($id){
   	   $this->session->set_userdata('logged_user_id', $id);
   }
    function logout(){
            $this->session->sess_destroy();
	}
   function check_logged(){
		return ($this->session->userdata('logged_user'))?TRUE:FALSE;
	}
   function addEmail($email){
   		 $this->session->set_userdata('logged_user_email', $email);
   }
   
   function addUserID($user_id){
	 $this->session->set_userdata('logged_user_UserID', $user_id);
   } 
      
       function addUserName($username1){
	 $this->session->set_userdata('logged_user_Username', $username1);
   }                                                                                                                                                                                                                                                                                                                      
	function getEmail(){
		return $this->session->userdata('logged_user_email');
	}	
	
	function getUserID(){
		return $this->session->userdata('logged_user_id');
	}
	function getUserName(){
		return $this->session->userdata('logged_user_name');
	}
        
        function getUserEmail(){
		return $this->session->userdata('logged_user');
	}
}