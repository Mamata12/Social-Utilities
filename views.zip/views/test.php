<?php

$headers="From:info@social_utilities.com";
$Email = $_POST['Dadicatee_email_id'];
$mail_to=$Email;
$email_subject="Social Utilities Information";

if(isset($_POST['submit'])){
$Dedicator = $_POST['Dadicatorname'];
$link = $_POST['Dedication_item'];
$email_message .= "\t".$Dedicator."dedicated you a post".$link"\n";

mail($mail_to,$email_subject,$email_message,$headers);
echo "<script>alert('Thank you for Contacting us.......!')</script>";
}
?>

<meta http-equiv='refresh' content='0;url=index.php'>