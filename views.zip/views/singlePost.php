<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title>Social Utility | Home</title>
        <meta name="generator" content="Bootply" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


      
         <link href=<?php echo base_url("//code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" ); ?>  rel="stylesheet" />
        
	    <link href=<?php echo base_url("css/bootstrap.min.css"); ?> rel='stylesheet' type='text/css' />
        <link href=<?php echo base_url("css/4-col-portfolio.css"); ?> rel='stylesheet' type='text/css' />
        <!--[if lt IE 9]>
                <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <link href=<?php echo base_url("css/styles.css"); ?> rel='stylesheet' type='text/css' />
        <link href=<?php echo base_url("css/liveurl.css"); ?> rel='stylesheet' type='text/css' />
		
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

<link href=<?php echo base_url("css/normalize.css"); ?> rel='stylesheet' type='text/css' />
<link href=<?php echo base_url("css/set1.css"); ?> rel='stylesheet' type='text/css' />
<link href=<?php echo base_url("css/set2.css"); ?> rel='stylesheet' type='text/css' />
<!--<link href=<?php echo base_url("css/demo.css"); ?> rel='stylesheet' type='text/css' />-->
<link rel="stylesheet" type="text/css" href="css/style6.css" />


  <link href=<?php echo base_url("css/mtree.css"); ?> rel='stylesheet' type='text/css' />
         <link href=<?php echo base_url("//code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" ); ?>  rel="stylesheet" />
        




 <link href=<?php echo base_url("css/hover.css"); ?> rel='stylesheet' type='text/css' />
 <link href=<?php echo base_url("css/toastr.css"); ?> rel='stylesheet' type='text/css' />

<script type="text/javascript" src=<?php echo base_url("js/jquery.min.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/jquery-ui.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/jquery.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/toastr.js"); ?>></script>


<link href=<?php echo base_url("tooltipstyles.css"); ?> rel='stylesheet' type='text/css' />
<link href=<?php echo base_url("css/jquery-ui.min.css"); ?> rel='stylesheet' type='text/css' />

<style>
.popover{
    width:200px;
    height:250px;  
}
.close1{
	 -webkit-appearance: none;
}

</style> 

<script>
 	function charactersonly(e){
 		
 		 var unicode= e.charCode? e.charCode : e.keyCode;
 		  if((unicode > 64 && unicode < 91) || (unicode > 96 && unicode < 122)||(unicode === 8)||(unicode=== 32)||(unicode===39)||(unicode===9)||(charCode === 37)||(charCode === 38)||(charCode === 39)||(charCode === 40) ){
		  		return true;
		  }else{
		  	   //alert("dfsdf");
		  	   
		  	    toastr.warning( 'Enter Characters only');
    			return false;
		  }
    }
    
   
  
   
    
    
    function validateEmail() {
            var email = document.getElementById("email").value;
            var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
            if(email.match(emailReg)){
            	
              			return true;
            } else {
                     toastr.warning( 'Enter Valid Email Id ');
    				 return false;
            }

        }
        
                
function numbersonly(e){      
var unicode=e.charCode? e.charCode : e.keyCode
if (unicode!=8){ //if the key isn't the backspace key (which we should allow)
if (unicode<48||unicode>57){ //if not a number
    
    $("#confirmOverlayAlert").css('display', 'block');
    $("#showErrorMessage").html("Enter only number");
return false; //disable key press
}
}
}
 </script>    

<script>
  $(function() {
    var availableTags = [
      "Images",
      "Videos",
      "Files",
      "Poem",
      "Text",
    
    ];
    $( "#Dedication_item_type" ).autocomplete({
      source: availableTags
    });
  });
  </script>
  
  
  
  
  <script>
   $(function() {
        $("#forgotpass" ).click(function(){
       	$('#myModal').hide();
		$( ".close" ).trigger( "click" );
       });
      
  });
  	
 
  </script>
  
    </head>
    <body>
 
<div id="deleteconfirm" class="overlayfixed" style="display: none;">
						<div id="confirmBox" class="overlayContent alert">

							<h4 id="deletshowErrorMessage" >
							</h4>
							<div id="confirmButtons">
								<a id="Yes1" deleteID="" class="button blue NoShare">
									OK
								
								</a>
								<a id="No" class="button blue NoShare">
								Cancel
								
								</a>


							</div>

						</div>
					</div>
		
 
        <div class="box">

            <?php include("header.html"); ?>
             
            <div class="column col-md-12 col-sm-12 col-xs-12" >
                <div class="padding">

                    <!-- content -->                      
                    <div class="row">

                        <!-- main col left --> 
                        <div class="col-sm-2">
                        
                          <div id="menu">
    <?php include("menu.html"); ?>
    
	</div>
                      <!--      <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/1.jpg"); ?>" class="img-responsive"></div>     
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/2.jpg"); ?>" class="img-responsive"></div>
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/3.jpg"); ?>" class="img-responsive"></div>
                            </div>-->


                        </div>

                        <div class="col-sm-8">


                            <div class="col-lg-12 appendnew" id="gallery" style="padding-right: 0px;padding-left: 0px;">

                                <!--                                  <div class="col-md-6 item" style="padding-left: 0px;">
                                                                        <div class="panel panel-default" >
                                                                            <div class="col-md-12" style="box-shadow: 5.5px 5.5px 12px -7px #B0B0B0;background: rgba(46, 38, 10, 0.55) none repeat scroll 0% 0%;color: white;height: 23px;">
                                                                                <lable>Shridhar Dedicated To Pune</lable>
                                                                            </div>
                                                                            <div class="col-md-12" style="display: none;">
                                                                               <textarea style="width: 300px; height: 100px;visibility: hidden;" placeholder="write here">http://im.rediff.com/news/2015/sep/02wild1.jpg</textarea> 
                                                                            </div>
                                                                            <div class="panel-thumbnail">
                                                                               <div class="liveurl">
                                                                                    <div class="inner">
                                                                                        <div class="image"> </div>
                                                                                        <div class="details">
                                                                                            <div class="info">
                                                                                                <div class="title"> </div>
                                                                                                <div class="description"> </div> 
                                                                                                <div class="url"> </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="panel-body">
                                                                                <p class="lead" style="margin: 0px;font-size: 14px;font-weight: bold;">Whenever You're Gone, I'm Here For You</p>
                                                                                <p style="margin: 0px;font-size: 13px;">I'm not a very good sleeper. But you know what? I'm willing to put in a few extra hours every day to get better. That's just the kind of hard worker I am. </p>
                                                                                <a style="float: right;font-size: 11px;" id='ReadMore'>Read More</a> 
                                
                                                                            </div>
                                                                            <div class="fb-comments" data-href="http://localhost/facebooka/1" data-colorscheme="light" data-numposts="2" data-width="400"></div>
                                                                        </div>
                                
                                                                    </div>
                                
                                                                    <div class="col-md-6 item" style="padding-left: 0px;">
                                                                        <div class="panel panel-default" >
                                                                            <div class="panel-thumbnail"><img src="<?php echo base_url("image/8.jpg"); ?>" class="img-responsive"></div>
                                                                            <div class="panel-body">
                                                                                <p class="lead">Urbanization</p>
                                                                                <p>45 Followers, 13 Posts</p>
                                
                                                                                <p>
                                                                                    <img src="https://lh3.googleusercontent.com/uFp_tsTJboUY7kue5XAsGA=s28" width="28px" height="28px">
                                                                                </p>
                                                                            </div>
                                                                            <div class="fb-comments" data-href="http://localhost/facebooka/2" data-colorscheme="light" data-numposts="2" data-width="400"></div>
                                                                        </div>
                                
                                                                    </div>
                                
                                                                    <div class="col-md-6 item" style="padding-left: 0px;">
                                                                        <div class="panel panel-default" >
                                                                            <div class="panel-thumbnail"><img src="<?php echo base_url("image/8.jpg"); ?>" class="img-responsive"></div>
                                                                            <div class="panel-body">
                                                                                <p class="lead">Urbanization</p>
                                                                                <p>45 Followers, 13 Posts</p>
                                
                                                                                <p>
                                                                                    <img src="https://lh3.googleusercontent.com/uFp_tsTJboUY7kue5XAsGA=s28" width="28px" height="28px">
                                                                                </p>
                                                                            </div>
                                                                            <div class="fb-comments" data-href="http://localhost/facebooka/3" data-colorscheme="light" data-numposts="2" data-width="400"></div>
                                                                        </div>
                                
                                                                    </div>
                                
                                                                    <div class="col-md-6 item" style="padding-left: 0px;">
                                                                        <div class="panel panel-default" >
                                                                            <div class="panel-heading"><a href="#" class="pull-right">View all</a> <h4>Bootstrap Examples</h4></div>
                                                                            <div class="panel-body">
                                                                                <div class="list-group">
                                                                                    <a href="http://bootply.com/tagged/modal" class="list-group-item">Modal / Dialog</a>
                                                                                    <a href="http://bootply.com/tagged/datetime" class="list-group-item">Datetime Examples</a>
                                                                                    <a href="http://bootply.com/tagged/datatable" class="list-group-item">Data Grids</a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="fb-comments" data-href="http://localhost/facebooka/7" data-colorscheme="light" data-numposts="2" data-width="400"></div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6 item" style="padding-left: 0px;">
                                                                        <div class="panel panel-default" >
                                                                            <div class="panel-thumbnail"><img src="<?php echo base_url("image/8.jpg"); ?>" class="img-responsive"></div>
                                                                            <div class="panel-body">
                                                                                <p class="lead">Urbanization</p>
                                                                                <p>45 Followers, 13 Posts</p>
                                
                                                                                <p>
                                                                                    <img src="https://lh3.googleusercontent.com/uFp_tsTJboUY7kue5XAsGA=s28" width="28px" height="28px">
                                                                                </p>
                                                                            </div>
                                                                            <div class="fb-comments" data-href="http://localhost/facebooka/4" data-colorscheme="light" data-numposts="2" data-width="400"></div>
                                                                        </div>
                                
                                                                    </div>
                                                                    <div class="col-md-6 item" style="padding-left: 0px;">
                                                                        <div class="panel panel-default">
                                                                            <div class="panel-thumbnail"><img src="<?php echo base_url("image/10.jpg"); ?>" class="img-responsive"></div>
                                                                            <div class="panel-body">
                                                                                <p class="lead">Urbanization</p>
                                                                                <p>45 Followers, 13 Posts</p>
                                
                                                                                <p>
                                                                                    <img src="https://lh3.googleusercontent.com/uFp_tsTJboUY7kue5XAsGA=s28" width="28px" height="28px">
                                                                                </p>
                                                                            </div>
                                                                            <div class="fb-comments" data-href="http://localhost/facebooka/5" data-colorscheme="light" data-numposts="2" data-width="400"></div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6 item" style="padding-left: 0px;">
                                                                        <div class="panel panel-default" >
                                                                            <div class="panel-heading"><a href="#" class="pull-right">View all</a> <h4>Bootstrap Examples</h4></div>
                                                                            <div class="panel-body">
                                                                                <div class="list-group">
                                                                                    <a href="http://bootply.com/tagged/modal" class="list-group-item">Modal / Dialog</a>
                                                                                    <a href="http://bootply.com/tagged/datetime" class="list-group-item">Datetime Examples</a>
                                                                                    <a href="http://bootply.com/tagged/datatable" class="list-group-item">Data Grids</a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="fb-comments" data-href="http://localhost/facebooka/6" data-colorscheme="light" data-numposts="2" data-width="400"></div>
                                                                        </div>
                                                                    </div>-->
                            </div>
                            <!--                                <div id="LoadMoreClick" class="col-md-12" style="height: 30px;left: 0px;margin-bottom: 25px;color: #FFF;background: linear-gradient(to bottom, rgba(88,147,0,0.3) 0%, rgba(0,0,0,39) 100%);border-radius: 6px;">
                                                                <p id="LoadmOrePost_Text" style="width: 100%;text-align: center;margin: 5px;font-size: 14px;font-weight: bold;cursor: pointer;">Load More..</p>
                                                            </div>-->

                        </div>


                        <div class="col-sm-2 ">
                   <!--         <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/5.jpg"); ?>" class="img-responsive"></div>     
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/6.jpg"); ?>" class="img-responsive"></div>
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/7.jpg"); ?>" class="img-responsive"></div>
                            </div>	-->

                        </div>
                    </div>


                </div>




            </div><!--/row-->

        </div><!-- /padding -->
  
     <!-- Model Change Password-->
 <div class="modal fade" id="ChangePasswordModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content"  >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style="text-align: center;color: #f5f5f5;">Change Password</h4>
                </div>

                <div class="account-form">
						<form id="change_Pass_form"  method="post">
						 <ul class="form-list row">
                            <li class="col-md-12 col-sm-12"> 
										<input type="text" required  class="input-text" id="oldpass" name="oldpass"  placeholder="Enter Old Password">
										
							</li>	
							  <li class="col-md-12 col-sm-12"> 
										<input type="text" required  class="input-text" id="newpass" name="newpass"  placeholder="Enter New Password">
										
							</li>	
							  <li class="col-md-12 col-sm-12"> 
										<input type="text" required  class="input-text" id="connewpass" name="confnewpass"  placeholder="Confirm New Password">
										
							</li>	
							 <li class="col-md-12 col-sm-12">
                            <span id="msg2"></span></li>
                        
							 <li class="col-md-12 col-sm-12"> 		
							 
										 <button class="btn btn-info hvr-sweep-to-right" id="change_pass_button" type="submit" style="" ><span>Submit</span></button>
							</li>
						</ul>				
						</form>
				 </div> 
            </div>
        </div>
    </div>
    <!-- Model Change Password--> 
    
    
    <!-- Model Forgot Password-->
 <div class="modal fade" id="ForgotPassModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content"  >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style="text-align: center;color: #f5f5f5;">Forgot Password</h4>
                </div>

                <div class="account-form">
						<form id="forgot_pass_form"  method="post">
						 <ul class="form-list row">
                            <li class="col-md-12 col-sm-12"> 
                            
										<input type="text" required  class="input-text" id="fpemailid" name="fpemail" onkeyup=" validateEmail1();" placeholder="Enter You Email ID">
										
							</li>	
							 <li class="col-md-12 col-sm-12">
                            <span id="msg2"></span></li>
                        
							 <li class="col-md-12 col-sm-12"> 		
							 
										 <button class="btn btn-info hvr-sweep-to-right" id="forgot_password_button" type="submit" ><span>Submit</span></button>
							</li>
						</ul>				
						</form>
				 </div> 
            </div>
        </div>
    </div>
    <!-- log in -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content" >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style="text-align: center;color: #f5f5f5;">LogIn</h4>
                </div>

                <div class="account-form">
                    <form method="post" id="login_form" class="form-login">

                        <ul class="form-list row">
                            <li class="col-md-12 col-sm-12"> 
                                <button type="button" class="btn btn-primary btn-lg" >Sign In With Facebook</button>
                            </li>
                            <li class="col-md-12 col-sm-12"> 
                                <button type="button" class="btn btn-danger btn-lg">Sign In With Twitter</button>
                            </li>
                            <li class="col-md-12 col-sm-12">

                                <input required type="text" name="username" class="input-text" placeholder="User Name or Email">
                            </li>
                            <li class="col-md-12 col-sm-12">

                                <input required type="password" name="pass" class="input-text" placeholder="Password" id="loginpass">
                            </li> 
                             <li class="col-md-6 col-sm-12 pwd text-right" style="float: right; ">
                                
                                 <p style="float:right;" id="forgotpass" style="color: #46b8da;padding-right: 26px;"> <a href="#" style="color:#0a4661" data-toggle="modal" data-target="#ForgotPassModal"> Forgot Password? </a> </p>                                                  		
                            </li>

                            <li class="col-md-12 col-sm-12">
                           <span id="msg1"></span>
                           </li>
                        </ul>
                        <div class="buttons-set" style="padding-top:20px">
                         
                            <button type="button" class="btn btn-info hvr-sweep-to-right" id="login_button" type="submit" style="width: 25%;
                                    margin-top: -45px;;margin-left: 56px;"><span>Login</span></button>
                        </div>
                    </form>
                </div> 

            </div>

        </div>
    </div>

    <!-- sign up -->
    <div class="modal fade" id="myModal1" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content" >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style="text-align:center;color: #f5f5f5;">Sign-Up </h4>
                </div>
                <div class="account-form">                        
                    <form method="post" class="form-login" id="register_form">
                        <ul class="form-list row">

                            <li class="col-md-12 col-sm-12">

                                <input  type="text" class="input-text" placeholder="Full Name *" id="rname" onkeypress="return countChar1(event)"  name="fullname" required>
                            </li>
                            <li class="col-md-12 col-sm-12">

                                <input  type="text" class="input-text" placeholder="Email Address *" id="uemail" onkeypress="validateEmail();"  name="email" required>
                            </li> 
                            <li class="col-md-12 col-sm-12">

                                <input  type="text" class="input-text" placeholder="Contact Number *" id="mno" maxlength="10"   onkeypress="return countmobile(event)" name="mno" required>
                            </li> 
                            <li class="col-md-12 col-sm-12">

                                <input  type="password" class="input-text" placeholder="Password *"  onkeypress="return checkPwd(event)" id="pass" name="pass" required>
                            </li>
                            <li class="col-md-12 col-sm-12">                                                
                                <span ><input class="input-chkbox" type="checkbox" style="width: 3.5%;"></span>
                                <p style=" margin-top: -38px;margin-left: 17px;">Accept Terms and Conditions</p>
                            </li>
                            <span id="msg"></span> <br>
                            <span id="msgpop"></span> 
                        </ul>
                        <div class="buttons-set">
                            <button type="submit"  class="btn btn-info submit hvr-sweep-to-right" id="register_button" onc  style="width: 25%; 
                                    margin-top: 5px;margin-left: 56px;margin-bottom: 20px;">Register</button>
                        </div>
                    </form>
                </div> 
            </div>

        </div>
    </div>

    <!-- script references -->
<!--    <script src=<?php //echo base_url("js/jquery-1.7.js");                            ?>></script>-->
<!--    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>-->
     <script type="text/javascript" src=<?php echo base_url("js/jquery.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/bootstrap.min.js"); ?>></script> 
    <script type="text/javascript" src=<?php echo base_url("js/jquery-1.10.2.min.js"); ?>></script>
        <script type="text/javascript" src=<?php echo base_url('js/jquery-ui.min.js'); ?>></script>
  <!--  <script type="text/javascript" src=<?php echo base_url("js/jquery.masonry.js"); ?>></script>   -->
    <script type="text/javascript" src=<?php echo base_url("js/jquery.preloader.min.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/jquery.form.min.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/scripts.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/jquery.liveurl.js"); ?>></script>
  
    <style>
        .preloader { background:url(<?php echo base_url . "image/728.GIF" ?>) center center no-repeat #ffffff;  }
        
        
    </style>
 
<script>
 $(document).ready(function() {
               
 	$("#searchbtn").click(function(){
 		var sdata = $("#countryname_1").val();
 		if(sdata == ""){
						 toastr.warning( 'Enter Search Data');
    						return false;
		}
		else{
			  window.location = "http://localhost/NewSocialUtilities/index.php/Searchresult?searchdata="+sdata;
                    //      window.location="http://whitecode.in/demo/social_utilities/index.php/Searchresult?searchdata="+sdata;   
		}
 		
						
        });    
        });
 </script>
 
<script>
              
            var  Dadicatorname = null;
            var  user_id=0;
            var  Dadicator_email_id = null;
            var  Dadicateename = null;
            var  Dadicatee_email_id = null;
            var  Dedication_title = null;
            var  Dedication_City = null;
                 
            $(document).ready(function() {
               
                $("#countryname_1").each(function(i, el) {
                    el = $(el);
                    el.autocomplete({
                        source: function(request, response) {
                            var xx = request.term;
                           
                            if (xx !== '') {
                                $.ajax({
                                    url: "<?php echo base_url() . 'index.php/Welcome/GetSearchData' ?>",
                                    dataType: "json",
                                    method: 'post',
                                    data: {
                                        name_startsWith: request.term,
                                        type: 'layouts',
                                        row_num: 1
                                    },
                                    success: function(data) {
                                            
                                        response($.map(data, function(item) {
                                            var code = item.split("|");
                                          
                                            return {
                                                label: code[0],
                                                value: code[0],
                                                data: code[1]
                                            }
                                        }));
                                        var getid = el.attr('id');
                                        $(".ui-autocomplete").css("z-index", "9999999999");
                                    }
                                });
                            } else
                            {
                                $("#ui-id-1").css("display", "none");
                            }
                        },
                        	autoFocus: true,
                        	minLength: 0,
                        	select: function(event, ui) {
                            var ID = ui.item.data.split("|");
                            myFunction(ID);
                        }
                    });
                });
            });
            
            
           function myFunction(id) {
                user_id = id;
                window.location="http://localhost/NewSocialUtilities/index.php/Welcome/Singlepage?random="+user_id;
             //  window.location="http://whitecode.in/demo/social_utilities/index.php/Welcome/Singlepage?random="+user_id;   
               
            }

</script>
    
<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '241084682937166',
      xfbml      : true,
      version    : 'v2.6'
    });
  };

 	  function postToFeed($elee) {
       var elem = $elee;
	   
	    var ppost_categoryname = $(elem).attr("ppost_postcatogaryname");
		 var postdescription = $(elem).attr("postdescription");
		  var Imageurlpath = $(elem).attr("Imageurlpath");
		  var postdescriptionalldetails = $(elem).attr("postdescriptionalldetails");
		
		
    // calling the API ...
    var obj = {
      method: 'feed',
      redirect_uri: 'http://whitecode.in/demo/social_utilities/',
      link: 'http://whitecode.in/demo/social_utilities/',
      name: ppost_categoryname,
      caption: 'http://whitecode.in/demo/social_utilities/',
      description: postdescriptionalldetails,
	   picture :Imageurlpath,
    };

    function callback(response) {
      document.getElementById('msg').innerHTML = "Post ID: " + response['post_id'];
    }

    FB.ui(obj, callback);
  }
	
	(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));
	

</script>
<script type="text/javascript">
    $(document).ready(function()
    {

        function checkUrlVideo(test_url) {
            var testLoc = document.createElement('a');
            testLoc.href = test_url.toLowerCase();
            url = testLoc.hostname;
            var what;
            if (url.indexOf('youtube.com') !== -1) {
                what = 'Youtube';
            } else if (url.indexOf('vimeo.com') !== -1) {
                what = 'Vimeo';
            } else {
                what = 'None';
            }
            return what;
        }

        function getUrlVars() {
            var vars = {};
            var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m, key, value) {
                vars[key] = value;
            });
            return vars;
        }
        
        var GetUrlID = getUrlVars()["random"];
       

//            $(window).scroll(function()
//            {
//
//                var myWidth = document.body.clientWidth;
//                var myHeight = document.body.clientHeight;
//                if ($(window).scrollTop() + 1 >= $(document).height() - myHeight)
//                {
//                    LoadMorePost();
//                }
//            });
        // This Ajax Page Load Ajax For Load User Top Uploaded Post.
        //Start
        $.ajax({
            url: "<?php echo base_url() . 'index.php/Welcome/GetPostSinglePost' ?>",
            type: "POST",
            dataType: 'json',
            data: "GetUrlID=" + GetUrlID,
            success: function(data) {
            	//alert(data);
                window.mydata = data;
                var record_par_page = mydata[0].Rows;
                if (data == "") {
                    $("#LoadmOrePost_Text").html("No record found");
                     document.write('<center><b><h1 style="text-align: center;display: block;  height: 30px; padding-left: 110px; font-size: 44px;font-weight: 700;  text-align: center; text-decoration: none;text-shadow: 3px 1px #d9edf7;  border-radius: 2px;  color: rgb(53, 140, 234);  margin: 20px 27px -38px -45px;">No Records Found</h1></b></center>');
                }
                var el = "";

                $.each(record_par_page, function(key, data) {
                    sr = (key + 1);
                    var ShowComment = "";
                    if (data.ShowComments == "1") {
                        ShowComment = '<div class="fb-comments" data-href="http://localhost/facebooka/' + data.id + '" data-colorscheme="light" data-numposts="2" data-width="815"></div>';
                    } else {
                        ShowComment = "";
                    }
                   
                    var UppendImageVideoData = "";
                    var test = checkUrlVideo(data.Dedication_item);
                    if (test == "None") {
                        UppendImageVideoData = '<img style="width:817px;height: 400px;" class="active image' + data.id + '" src="">';
                    } else if (test == "Youtube") {
                        UppendImageVideoData = '<iframe width="815" height="400" src="' + data.Dedication_item + '" frameborder="0"></iframe>';
                    } else if (test == "Vimeo") {
                        UppendImageVideoData = '<iframe src=' + data.Dedication_item + ' width="815" height="400" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
                    }
                    
                    
                     	var dn= data.Dadicatorname;
                        var dedicatorname= dn[0].toUpperCase() + dn.slice(1);
                       
                        var den= data.Dadicateename;
                        var dedicateename= den[0].toUpperCase() + den.slice(1);
                       
						  var deletepost="";
                        
                        var sessionValue = "<?php echo $this->session->userdata('logged_user');?>";
                        var email=data.Dadicator_email_id;
                      
						if(sessionValue==email){
							 var deletepost='<div class="btn-group show-on-hover" style="float:right;margin-right: 12px; ">'+'<i class="caret dropdown-toggle" data-toggle="dropdown" style="color: blue;"></i>'+ '<ul class="dropdown-menu" role="menu"><li id="delete_post"><a id="' + data.id + '" class="deletePost" >Delete</a></li></ul>'+'</div>';
						}
						
						
						
					var desc=data.Dedication_message;
						
                    var linked=window.location.href;
                   
            //   var share='<div class="fb-share-button" onclick="postToFeed(this);" ppost_postcatogaryname="Mamata" postdescriptionalldetails="Alli" postdescription="PHP Developer" Imageurlpath="<?php echo base_url() . '+a+'; ?>" data-href="http://whitecode.in/demo/social_utilities/index.php" data-layout="button_count" data-mobile-iframe="true"></div>';
                    
					//var share='<div id="fb-root" onclick="postToFeed(this);" ppost_postcatogaryname="'+linked+'" postdescriptionalldetails="'+dn+"dedicated to"+den+'" postdescription="'+desc+'" Imageurlpath="'+UppendImageVideoData+'"></div>';
	 				
	 				  
				//	var share='<div id="fb-root" onclick="postToFeed(this);" ppost_postcatogaryname="http://whitecode.in/demo/social_utilities/index.php" postdescriptionalldetails="'+dn+"dedicated to"+den+'" postdescription="'+desc+'" Imageurlpath="'+UppendImageVideoData+'"></div>';
	 
	 
	 
	   //code for fetching thumbnail image of youtube
                        
                         if (test == "Youtube") {
                        var iframe = $('iframe:first');
                        var iframe_src = data.Dedication_item;
                        var youtube_video_id = iframe_src.match(/youtube\.com.*(\?v=|\/embed\/)(.{11})/).pop();
                        if (youtube_video_id.length == 11) {
						//alert(youtube_video_id);
						imgurl = "//img.youtube.com/vi/"+youtube_video_id+"/0.jpg";
						//alert(imgurl);
						 var share='<div id="fb" onclick="postToFeed(this);" ppost_postcatogaryname="'+dn+" dedicated to "+den+'" postdescriptionalldetails="'+desc+'"  Imageurlpath="'+imgurl+'"></div>';
	 	
	  var share2='<div id="fb2" onclick="postToFeed(this);" ppost_postcatogaryname="'+dn+" dedicated to "+den+'" postdescriptionalldetails="'+desc+'"  Imageurlpath="'+imgurl+'"></div>';
						}
						}
	 
	 
	  if (test == "None") {
                         var share='<div id="fb" onclick="postToFeed(this);" ppost_postcatogaryname="'+dn+" dedicated to "+den+'" postdescriptionalldetails="'+desc+'"  Imageurlpath="'+data.Dedication_item+'"></div>';
	 	
	  var share2='<div id="fb2" onclick="postToFeed(this);" ppost_postcatogaryname="'+dn+" dedicated to "+den+'" postdescriptionalldetails="'+desc+'"  Imageurlpath="'+data.Dedication_item+'"></div>';
                    } 
	// var share='<div id="fb" onclick="postToFeed(this);" ppost_postcatogaryname="'+dn+" dedicated to "+den+'" postdescriptionalldetails="'+desc+'"  Imageurlpath="'+data.Dedication_item+'"></div>';
	 	
	//  var share2='<div id="fb2" onclick="postToFeed(this);" ppost_postcatogaryname="'+dn+" dedicated to "+den+'" postdescriptionalldetails="'+desc+'"  Imageurlpath="'+data.Dedication_item+'"></div>';
	 
						
                    el = '<div class="col-md-12 item " id="' + data.id + '" style="padding-left: 0px;">' +
                            '<div class="panel panel-defaul boxAlbum" >' +
                            '<div class="col-md-12 panel_color" style="background: #FFF none repeat scroll 0% 0%;height: auto; margin: 0% 0% 0%;padding: 2% 0% 2% 5%;">' +// font-weight: 700;color: #000000;
                            '<lable style="color: #0864C1;font-size: 18px;font-weight: bold;">' + dedicatorname + '</lable>' 
                            +'&nbsp;<label style="color: rgb(0, 0, 0);font-size: 12px;font-weight: 500;"> dedicated to </label>' + 
                            '&nbsp;<lable style="color: #0864C1; font-size: 18px; font-weight: bold;">'+ dedicateename + '</lable>' +deletepost+
                            '</div>' +share+
                            '<div class="col-md-12" style="display: none;">' +
                            '<textarea style="width: 300px; height: 100px;visibility: hidden;" class="textarea' + data.id + '" placeholder="write here">' +
                            data.Dedication_item +
                            '</textarea>' +
                            '</div>' +
                            '<div class="panel-thumbnail">' +
                            '<div class="liveurl liveurl' + data.id + '">' +
                            '<div class="inner inner' + data.id + '">' +
                            '<div class="image" style="width: 100%;">' +
                            UppendImageVideoData +
                            '</div>' +
                            '<div class="details details' + data.id + '">' +
                            ' <div class="info info' + data.id + '">' +
                           // '<div class="title title' + data.id + '"> </div>' +
                            '<div class="description description' + data.id + '"> </div>' +
                           // '<div class="url url' + data.id + '"> </div>' +
                            '</div>' +
                            '</div>' +
                            '</div>' +
                            '</div>' +
                            '</div>' +
                            '<div class="panel-body">' +
                             
                            // '<lable style="margin: 0px;font-size: 13px;font-weight: bold;" >' +
                             //'Dedicator Name ' + '</lable>'+data.Dadicatorname 
                            // +'</br>'+
                            // '<lable style="margin: 0px;font-size: 13px;font-weight: bold;">' +
                            // ' Dedicators Email id ' +  '</lable>' + data.Dadicator_email_id +
                            // '</br>'+
                            // '<lable style="margin: 0px;font-size: 13px;font-weight: bold; " >' +
                            // 'Dedicatee Name ' +'</lable>' + data.Dadicateename +
                            // '</br>'+
                            // '<lable style="margin: 0px;font-size: 13px;font-weight: bold;" >' +
                            // 'Dedicatees Email id ' +  '</lable>' + data.Dadicatee_email_id +
                            // '</br>'+
                           //  '<lable style="margin: 0px;font-size: 13px;font-weight: bold;" >' +
                           ////  'Dedication item type ' +  '</lable>' + data.Dedication_item_type +
                            //  '</br>'+
                            // '<lable style="margin: 0px;font-size: 13px;font-weight: bold;" >' +
                            // 'Dedication title	' +  '</lable>' + data.Dedication_title	 +
                           //  '</br>'+
                           //  '<lable style="margin: 0px;font-size: 13px;font-weight: bold;" >' +
                            // 'Dedication City ' +  '</lable>' + data.Dedication_City	 +
                             //'</br>'+
                             //'<lable style="margin: 0px;font-size: 13px;font-weight: bold;" >' +
                            // 'Dedication item ' +  '</lable>' + data.Dedication_item	 +
                            // '</br>'+
                             //'<lable style="margin: 0px;font-size: 13px;font-weight: bold;" >Message</lable>&nbsp;&nbsp;' +
                              '<p class="read-more-wrap" style="font-size: larger">'+data.Dedication_message	 +'</p>'+
                             // '</br>'+                        
                            // //'<lable style="margin: 0px;font-size: 13px;font-weight: bold;" >' +
                             //'Title ' +  '</lable>' + data.Dedication_title +
                                                   
                           // '<a style="float: right;font-size: 11px;" id="ReadMore">Read More</a>' +
                            '</div>' +
                           
                            ShowComment +'<input id="msg" type="hidden"/>'+share2+'</div>'+
                            '</div>'
                    $('.appendnew').append(el);
                    findUrls1('textarea' + data.id, data.id);
                    findUrls('textarea' + data.id);
                    
                    FB.XFBML.parse();
                });
            }
        });
//END OF Page Load User Post Load 


        //This Ajax Used For User Insert New Post
        //Start
//            $("#PostSubmit").click(function() {
//                var Dadicator_name = $("#Dadicatorname").val();
//                var Dadicator_email_id = $("#Dadicator_email_id").val();
//                var Dadicatee_name = $("#Dadicateename").val();
//                var Dadicatee_email_id = $("#Dadicatee_email_id").val();
//                var Dedication_item_type = $("#Dedication_item_type").val();
//                var Dedication_title = $("#Dedication_title").val();
//                var Dedication_City = $("#Dedication_City").val();
//                var Dedication_item = $("#Dedication_item").val();
//                var Dedication_message = $("#Dedication_message").val();
//                var Dedication_Theme = $("#Dedication_Theme").val();
//                var ShowPageViewCount = "False";
//                var lfckv = document.getElementById("lifecheck").checked;
//                var el = "";
//                $('#ShratThoughtForm').ajaxForm(
//                        {
//                            target: '',
//                            cache: false,
//                            beforeSend: function() {
//                            },
//                            success: function(responseText)
//                            {
//                                var ShowComment = "";
//                                if (lfckv == true) {
//                                    ShowComment = '<div class="fb-comments" data-href="http://localhost/facebooka/' + responseText + '" data-colorscheme="light" data-numposts="2" data-width="400"></div>';
//                                } else {
//                                    ShowComment = "";
//                                }
//                                var UppendImageVideoData = "";
//                                var test = checkUrlVideo(data.Dedication_item);
//                                if (test == "None") {
//                                    UppendImageVideoData = '<img class="active image' + responseText + '" src="">';
//                                } else if (test == "Youtube") {
//                                    UppendImageVideoData = '<iframe width="420" height="315" src="' + Dedication_item + '" frameborder="0"></iframe>';
//                                } else if (test == "Vimeo") {
//                                    UppendImageVideoData = '<iframe src=' + Dedication_item + ' width="400" height="315" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
//                                }
//
//                                el = '<div class="col-md-6 item" id="' + responseText + '" style="padding-left: 0px;"><a href="<?php // echo base_url() . 'index.php/Welcome/Singlepage'  ?>" >' +
//                                        '<div class="panel panel-default" >' +
//                                        '<div class="col-md-12" style="box-shadow: 5.5px 5.5px 12px -7px #B0B0B0;background: #305A63 none repeat scroll 0% 0%;color: white;height: 23px;">' +
//                                        '<lable>' +
//                                        Dadicator_name + ' Dedicated To ' + Dadicatee_name +
//                                        '</lable>' +
//                                        '</div>' +
//                                        '<div class="col-md-12" style="display: none;">' +
//                                        '<textarea style="width: 300px; height: 100px;visibility: hidden;" class="textarea' + responseText + '" placeholder="write here">' +
//                                        Dedication_item +
//                                        '</textarea>' +
//                                        '</div>' +
//                                        '<div class="panel-thumbnail">' +
//                                        '<div class="liveurl liveurl' + responseText + '">' +
//                                        '<div class="inner inner' + responseText + '">' +
//                                        '<div class="image">' +
//                                        UppendImageVideoData +
//                                        '</div>' +
//                                        '<div class="details details' + responseText + '">' +
//                                        ' <div class="info info' + responseText + '">' +
//                                        '<div class="title title' + responseText + '"> </div>' +
//                                        '<div class="description description' + responseText + '"> </div>' +
//                                        '<div class="url url' + responseText + '"> </div>' +
//                                        '</div>' +
//                                        '</div>' +
//                                        '</div>' +
//                                        '</div>' +
//                                        '</div>' +
//                                        '<div class="panel-body">' +
//                                        '<p class="lead" style="margin: 0px;font-size: 14px;font-weight: bold;">' +
//                                        Dedication_title +
//                                        '</p>' +
//                                        '<p style="margin: 0px;font-size: 13px;">' +
//                                        Dedication_message +
//                                        '</p>' +
//                                        '<a style="float: right;font-size: 11px;" id="ReadMore">Read More</a>' +
//                                        '</div>' +
//                                        ShowComment +
//                                        '</a></div>'
//
//                                jQuery(".appendnew").prepend(el).masonry('reloadItems');
//                                findUrls1('textarea' + responseText, responseText);
//                                findUrls('textarea' + responseText);
//                                $('.appendnew').masonry();
//                                FB.XFBML.parse();
//                            },
//                            complete: function() {
//                            }
//                        }).submit();
//            });
// END of sumbit new post

//This Ajax Used For Load More post
//Start
//            function LoadMorePost() {
//                var ID = "";
//                ID = $(".appendnew").children().last().attr('id');
//                $.ajax({
//                    url: "<?php //echo base_url() . 'index.php/Welcome/LoadMorePost'  ?>",
//                    type: "POST",
//                    dataType: 'json',
//                    data: "lastPostID=" + ID,
//                    success: function(data) {
//                        window.mydata = data;
//                        var record_par_page = mydata[0].Rows;
//                        if (data == "") {
//                            $("#LoadmOrePost_Text").html("No record found");
//                        }
//                        var el = "";
//                        $.each(record_par_page, function(key, data) {
//                            sr = (key + 1);
//                            var ShowComment = "";
//                            if (data.ShowComments == "1") {
//                                ShowComment = '<div class="fb-comments" data-href="http://localhost/facebooka/' + data.id + '" data-colorscheme="light" data-numposts="2" data-width="400"></div>';
//                            } else {
//                                ShowComment = "";
//                            }
//                            var UppendImageVideoData = "";
//                            var test = checkUrlVideo(data.Dedication_item);
//                            if (test == "None") {
//                                UppendImageVideoData = '<img class="active image' + data.id + '" src="">';
//                            } else if (test == "Youtube") {
//                                UppendImageVideoData = '<iframe width="420" height="315" src="' + data.Dedication_item + '" frameborder="0"></iframe>';
//                            } else if (test == "Vimeo") {
//                                UppendImageVideoData = '<iframe src=' + data.Dedication_item + ' width="400" height="315" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
//                            }
//
//                            el = '<div class="col-md-6 item" id="' + data.id + '" style="padding-left: 0px;"><a href="<?php echo base_url() . 'index.php/Welcome/Singlepage' ?>">' +
//                                    '<div class="panel panel-default" >' +
//                                    '<div class="col-md-12" style="box-shadow: 5.5px 5.5px 12px -7px #B0B0B0;background: #305A63 none repeat scroll 0% 0%;color: white;height: 23px;">' +
//                                    '<lable>' +
//                                    data.Dadicatorname + ' Dedicated To ' + data.Dadicateename +
//                                    '</lable>' +
//                                    '</div>' +
//                                    '<div class="col-md-12" style="display: none;">' +
//                                    '<textarea style="width: 300px; height: 100px;visibility: hidden;" class="textarea' + data.id + '" placeholder="write here">' +
//                                    data.Dedication_item +
//                                    '</textarea>' +
//                                    '</div>' +
//                                    '<div class="panel-thumbnail">' +
//                                    '<div class="liveurl liveurl' + data.id + '">' +
//                                    '<div class="inner inner' + data.id + '">' +
//                                    '<div class="image">' +
//                                    UppendImageVideoData +
//                                    '</div>' +
//                                    '<div class="details details' + data.id + '">' +
//                                    ' <div class="info info' + data.id + '">' +
//                                    '<div class="title title' + data.id + '"> </div>' +
//                                    '<div class="description description' + data.id + '"> </div>' +
//                                    '<div class="url url' + data.id + '"> </div>' +
//                                    '</div>' +
//                                    '</div>' +
//                                    '</div>' +
//                                    '</div>' +
//                                    '</div>' +
//                                    '<div class="panel-body">' +
//                                    '<p class="lead" style="margin: 0px;font-size: 14px;font-weight: bold;">' +
//                                    data.Dedication_title +
//                                    '</p>' +
//                                    '<p style="margin: 0px;font-size: 13px;">' +
//                                    data.Dedication_message +
//                                    '</p>' +
//                                    '<a style="float: right;font-size: 11px;" id="ReadMore">Read More</a>' +
//                                    '</div>' +
//                                    ShowComment +
//                                    '</a></div>';
//                            $('.appendnew').append(el);
//                            findUrls1('textarea' + data.id, data.id);
//                            findUrls('textarea' + data.id);
//                        });
//                        FB.XFBML.parse();
//                        jQuery(".appendnew").masonry('reloadItems');
//                    }
//                });
//                $('.appendnew').masonry();
//            }
//            $(document.body).on('click', '#LoadMoreClick', function(e) {
//                var ID = "";
//                ID = $(".appendnew").children().last().attr('id');
//                $.ajax({
//                    url: "<?php //echo base_url() . 'index.php/Welcome/LoadMorePost'  ?>",
//                    type: "POST",
//                    dataType: 'json',
//                    data: "lastPostID=" + ID,
//                    success: function(data) {
//                        window.mydata = data;
//                        var record_par_page = mydata[0].Rows;
//                        if (data == "") {
//                            $("#LoadmOrePost_Text").html("No record found");
//                        }
//                        var el = "";
//                        $.each(record_par_page, function(key, data) {
//                            sr = (key + 1);
//                            var ShowComment = "";
//                            if (data.ShowComments == "1") {
//                                ShowComment = '<div class="fb-comments" data-href="http://localhost/facebooka/' + data.id + '" data-colorscheme="light" data-numposts="2" data-width="400"></div>';
//                            } else {
//                                ShowComment = "";
//                            }

//                            el = '<div class="col-md-6 item" id="' + data.id + '" style="padding-left: 0px;">' +
//                                    '<div class="panel panel-default" >' +
//                                    '<div class="col-md-12" style="box-shadow: 5.5px 5.5px 12px -7px #B0B0B0;background: #305A63 none repeat scroll 0% 0%;color: white;height: 23px;">' +
//                                    '<lable>' +
//                                    data.Dadicatorname + ' Dedicated To ' + data.Dadicateename +
//                                    '</lable>' +
//                                    '</div>' +
//                                    '<div class="col-md-12" style="display: none;">' +
//                                    '<textarea style="width: 300px; height: 100px;visibility: hidden;" class="textarea' + data.id + '" placeholder="write here">' +
//                                    data.Dedication_item +
//                                    '</textarea>' +
//                                    '</div>' +
//                                    '<div class="panel-thumbnail">' +
//                                    '<div class="liveurl liveurl' + data.id + '">' +
//                                    '<div class="inner inner' + data.id + '">' +
//                                    '<div class="image">' +
//                                    '<img class="active image' + data.id + '" src="">' +
//                                    '</div>' +
//                                    '<div class="details details' + data.id + '">' +
//                                    ' <div class="info info' + data.id + '">' +
//                                    '<div class="title title' + data.id + '"> </div>' +
//                                    '<div class="description description' + data.id + '"> </div>' +
//                                    '<div class="url url' + data.id + '"> </div>' +
//                                    '</div>' +
//                                    '</div>' +
//                                    '</div>' +
//                                    '</div>' +
//                                    '</div>' +
//                                    '<div class="panel-body">' +
//                                    '<p class="lead" style="margin: 0px;font-size: 14px;font-weight: bold;">' +
//                                    data.Dedication_title +
//                                    '</p>' +
//                                    '<p style="margin: 0px;font-size: 13px;">' +
//                                    data.Dedication_message +
//                                    '</p>' +
//                                    '<a style="float: right;font-size: 11px;" id="ReadMore">Read More</a>' +
//                                    '</div>' +
//                                    ShowComment +
//                                    '</div>';
//                            $('.appendnew').append(el);
//
//                            findUrls1('textarea' + data.id, data.id);
//                            findUrls('textarea' + data.id);
//                        });
//                        FB.XFBML.parse();
//                        jQuery(".appendnew").masonry('reloadItems');
//                    }
//                });
//                $('.appendnew').masonry();
//            });
//END Of Load More Post
    });
    var name_bit = 0;
        var email_bit = 0;
        var pass_bit = 0;
        var mno_bit = 0;
        $(document).ready(function() {

//            var Text = "I'm not a very good sleeper. But you know what? https://www.youtube.com/ I'm willing to put in a few extra hours every day to get better. https://www.google.co.in/?gfe_rd=cr&ei=_COGVuuZJqyl8weiqbOwAw  That's just the kind of hard worker I am";
//         //   alert(findUrls(Text));
//
//            function findUrls(text)
//            {
//                var source = (text || '').toString();
//                var urlArray = [];
//                var url;
//                var matchArray;
//                // Regular expression to find FTP, HTTP(S) and email URLs.
//                var regexToken = /(((ftp|https?):\/\/)[\-\w@:%_\+.~#?,&\/\/=]+)|((mailto:)?[_.\w-]+@([\w][\w\-]+\.)+[a-zA-Z]{2,3})/g;
//                // Iterate through any URLs in the text.
//                while ((matchArray = regexToken.exec(source)) !== null)
//                {
//                    var token = matchArray[0];
//                    urlArray.push(token);
//                }
//                return urlArray;
//            }


            // $('.appendnew').masonry();
//            $(function() {
//                $("#gallery").preloader();
//            });

//Alignd Masonary Every 1 Min
         //   setInterval(function() {
      //          $('.appendnew').masonry();
       //     }, 1500);
//END Set Intervel




//Delete post code
$(document.body).on('click', '.deletePost', function (e) {
	$("#deleteconfirm").css('display','block');
	$("#deletshowErrorMessage").html("Are you sure you want to delete this Post?");
	 var did = $(this);
	
	 var id = did.attr('id');//alert(did);
	 //alert("ID"+id);
	  //alert($(this).attr('id'));
	 $("#Yes1").attr("deleteID",id);
	 });
	
	 
	 
	 
	 
           $("#Yes1").click(function()	
			{
              
				id=$(this).attr('deleteID');
            $.ajax({
                type: "POST",
                dataType:'json',
                url: '<?php echo base_url() . "index.php/Welcome/delete_post"; ?>',
                data: "id=" + id ,
                beforeSend: function () { },
                success: function (result) {
                	//alert(result);
                    location.reload();

                },
                error: function (data) { }
           
        });

});

	$("#No").click(function(){
				 $("#deleteconfirm").css('display', 'none');
				
				});
				
//End of delete post				


//This Ajax Use for new User Ragisterd
            $("#register_button").click(function(e) {
            	
                if (email_bit == 1 && mno_bit == 1) {
                    $.ajax({
                        url: '<?php echo base_url() . "index.php/Welcome/register_database"; ?>',
                        type: "POST",
                        data: $('#register_form').serialize(),
                        cache: false,
                        beforeSend: function()
                        {
                        },
                        success: function(response) {
                        	 $("#register_form")[0].reset(); 
                        	 toastr.success(response);
                            // $("#msg").html(response);
                             location.reload();
                        }
                    })
                } else {
                    document.getElementById('msg').innerHTML = "Please Enter your details";
                }
                e.preventDefault();
            }); //on click form submit
//END New User Ragister

//This Ajax Used For User Login
		$("#loginpass").keypress(function (e){
                if (e.keyCode == 13) {
                	 var wrong = "Your account not activated. check your mail and activate your account.";
                var check = "Wrong credentials";
                var check2="Please Enter All Fields";
                $.ajax({
                    url: '<?php echo base_url() . "index.php/Welcome/login_check"; ?>',
                    type: "POST",
                    data: $('#login_form').serialize(),
                    cache: false,
                    beforeSend: function()
                    {
                    },
                    success: function(response) {
                   $("#login_form")[0].reset(); 
                       //alert(response);
                        if (response == 0) {
                            $("#msg1").html(wrong);
                        } else if (response == 2) {
                            $("#msg1").html(check);
                        }
                        else if (response == 1) {
                        	 toastr.success("Login Successfully");
                        	 //alert("Login Successfully");
                        	//  $("#confirmOverlayAlert").css('display', 'block');
   							//  $("#showErrorMessage").html("Enter only number");
                        	 window.location = "http://localhost/NewSocialUtilities/";
                           
                        	//window.location = "http://whitecode.in/demo/social_utilities/";
                        }
                         else if(response == -1){
							$("#msg1").html(check2);
						}
                    }
                });
                 e.preventDefault();
                }
              });
                
            $("#login_button").click(function() {
            	
                var wrong = "Your account not activated. check your mail and activate your account.";
                var check = "Wrong credentials";
                var check2="Please Enter All Fields";
                $.ajax({
                    url: '<?php echo base_url() . "index.php/Welcome/login_check"; ?>',
                    type: "POST",
                    data: $('#login_form').serialize(),
                    cache: false,
                    beforeSend: function()
                    {
                    },
                    success: function(response) {
                      $("#login_form")[0].reset(); 
                      // alert(response);
                        if (response == 0) {
                            $("#msg1").html(wrong);
                        } else if (response == 2) {
                            $("#msg1").html(check);
                        }
                        else if (response == 1) {
                        	 toastr.success("Login Successfully");
                        	 //alert("Login Successfully");
                            window.location = "http://localhost/NewSocialUtilities/";
                        	//window.location = "http://whitecode.in/demo/social_utilities/";
                        }
                         else if(response == -1){
							$("#msg1").html(check2);
						}
                    }
                });
            }); //on click form submit
//END OF Login
      
  //code for forgot passward  
     $("#forgot_password_button").click(function() {
            
            var email = document.getElementById("fpemailid").value;
            var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
            if(email==''){
				 document.getElementById('msg2').innerHTML = "Enter email address" 
			}else if (emailReg.test(email) == false) {
               email_bit = 0;
                document.getElementById('msg2').innerHTML = "Invalid email address"
                return false;
               
            }else if (emailReg.test(email) == true) {
                email_bit = 1;
                 document.getElementById('msg2').innerHTML = ""
                
            }

       
                $.ajax({
                    url: '<?php echo base_url() . "index.php/Welcome/forgot_pass_check"; ?>',
                    type: "POST",
                    data: $('#forgot_pass_form').serialize(),
                    cache: false,
                    beforeSend: function()
                    {
                    	
                    },
                    success: function(response) {
                       $("#forgot_pass_form")[0].reset(); 
						//alert(response);  
						 
						 if(response==1){ 
						 document.getElementById('msg2').innerHTML = response;
						 				//alert("sdfsf"); 
						 				// e.preventDefault();     
						 				// return true;
						 				//window.location.href;
						 				
						 }else  if(response==0){
						 			 	document.getElementById('msg2').innerHTML = "Please Enter Your Email Id";
						 			 	// e.preventDefault();     
						 				// return false;
						 			 	
               			 }else  if(response==2){
						 			 	document.getElementById('msg2').innerHTML = "You are not an registered user please register.";
               			 }
                               
                    }
                
                });
            //on click form submit
//END OF Forgot Password   
  
        });
        
        
        
        
        
        
   });       
        
   function countChar1(val) {
   			var textbox = document.getElementById("rname").value;
           
            if (textbox.length < 2) {
                name_bit = 0;
                 document.getElementById('msg').innerHTML =  "Enter characters of minimum length 3"
              //   document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
            //     document.getElementById('mno').disabled = true;
            //     document.getElementById('uemail').disabled = true;
             //    document.getElementById('pass').disabled = true;
            } else {
            	 
                 document.getElementById('msg').innerHTML = ""
                 document.getElementById('msgpop').innerHTML =  ""
           //      document.getElementById('mno').disabled = false;
           //      document.getElementById('uemail').disabled = false;
           //      document.getElementById('pass').disabled = false;
                 name_bit = 1;
            }
            
             val = (val) ? val : window.event;
            var charCode = (val.which) ? val.which : val.keyCode;
              if((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 122)||(charCode === 8)||(charCode=== 32)||(charCode===39)||(charCode===9)||(charCode === 37)||(charCode === 38)||(charCode === 39)||(charCode === 40)){
              	
                return true;
            }
            return false;
        }

       
        function countmobile(evt) {
            var textbox = document.getElementById("mno").value;
            if (textbox.length < 9) {

                document.getElementById('msg').innerHTML = "Enter a 10 digit Phone no."
             //   document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
             ////    document.getElementById('rname').disabled = true;
              //  document.getElementById('uemail').disabled = true;
              //  document.getElementById('pass').disabled = true;
                //  document.getElementById('cpass').disabled = true;
                mno_bit = 0;
            } else if (textbox.length > 10) {
                document.getElementById('msg').innerHTML = "Enter a 10 digit Phone no."
                //document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
              //   document.getElementById('rname').disabled = true;
             //   document.getElementById('uemail').disabled = true;
             //   document.getElementById('pass').disabled = true;
                // document.getElementById('cpass').disabled = true;
                mno_bit = 0;
            } else {
                document.getElementById('msg').innerHTML = ""
                document.getElementById('msgpop').innerHTML =  ""
              //  document.getElementById('rname').disabled = false;
             //   document.getElementById('uemail').disabled = false;
             //   document.getElementById('pass').disabled = false;
                mno_bit = 1;
            }

            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }



		 

        function validateEmail() {
            var email = document.getElementById("uemail").value;
           var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,3})?$/;
            if (emailReg.test(email) == false) {
                email_bit = 0;
                document.getElementById('msg').innerHTML = "Invalid email address"
               // document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
               // document.getElementById('rname').disabled = true;
               // document.getElementById('mno').disabled = true;
               // document.getElementById('pass').disabled = true;
            } else {
                 email_bit = 1;
                 document.getElementById('msg').innerHTML = ""
                 document.getElementById('msgpop').innerHTML =  ""
                // document.getElementById('rname').disabled = false;
                // document.getElementById('mno').disabled = false;
                 //document.getElementById('pass').disabled = false;
            }

        }


        function checkPwd(val) {

            var str = document.getElementById("pass").value;
            
            if ((str.length < 4)) {
                document.getElementById('msg').innerHTML = "Password must have min 4 character "
                pass_bit = 1;
           
            }else{
				 document.getElementById('msg').innerHTML = ""
                pass_bit = 0;
			}
                
        }



    </script>
    <script>

        var curImages = new Array();
        function findUrls(text)
        {
            $('.' + text).trigger('keyup');
        }
        function findUrls1(text, id)
        {
            $('.' + text).liveUrl({
                loadStart: function() {
                },
                loadEnd: function() {
                },
                success: function(data)
                {
                    var output = $('.liveurl' + id);
                    output.find('.title' + id).text(data.title);
                    output.find('.description' + id).text(data.description);
                    var URL = '<a href="' + data.url + '" target="_blank">' + data.url + '</a>'
                    output.find('.url' + id).html(URL);
                    output.find('.image' + id).empty();
                    output.show('fast');



                },
                addImage: function(image)
                {
                    var output = $('.liveurl' + id);
                    var jqImage = $(image);
                    var newimage = jqImage.attr('src');
                    output.find('.image' + id).attr('src', newimage);
                    $('.appendnew').imagesLoaded(function() {
                        $("#gallery").preloader();
                        $('.appendnew').masonry();
                    });
                }
            });
        }
    </script>
</body>
</html>    