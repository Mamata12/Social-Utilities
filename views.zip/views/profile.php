<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title>Social Utility | Home</title>
        <meta name="generator" content="Bootply" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        
        
         <link href=<?php echo base_url("//code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" ); ?>  rel="stylesheet" />
        
	    <link href=<?php echo base_url("css/bootstrap.min.css"); ?> rel='stylesheet' type='text/css' />
        <link href=<?php echo base_url("css/4-col-portfolio.css"); ?> rel='stylesheet' type='text/css' />
        <!--[if lt IE 9]>
                <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <link href=<?php echo base_url("css/styles.css"); ?> rel='stylesheet' type='text/css' />
        <link href=<?php echo base_url("css/liveurl.css"); ?> rel='stylesheet' type='text/css' />
		
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
 <link href=<?php echo base_url("css/toastr.css"); ?> rel='stylesheet' type='text/css' />

<link href=<?php echo base_url("css/normalize.css"); ?> rel='stylesheet' type='text/css' />
<link href=<?php echo base_url("css/set1.css"); ?> rel='stylesheet' type='text/css' />
<link href=<?php echo base_url("css/set2.css"); ?> rel='stylesheet' type='text/css' />
<!--<link href=<?php echo base_url("css/demo.css"); ?> rel='stylesheet' type='text/css' />-->
<link rel='stylesheet' type='text/css'' href= <?php echo base_url("css/style6.css"); ?> />


<script type="text/javascript" src=<?php echo base_url("js/jquery.min.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/jquery-ui.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/jquery.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/toastr.js"); ?>></script>


<link href=<?php echo base_url("tooltipstyles.css"); ?> rel='stylesheet' type='text/css' />
<link href=<?php echo base_url("css/jquery-ui.min.css"); ?> rel='stylesheet' type='text/css' />

<style>
.popover{
    width:200px;
    height:250px;  
}</style> 

<script>
$(document).ready(function(){
				//toastr.success('Are you the six fingered man?', 'Inigo Montoya');
				//var priority = 'danger';
             //   var title = '';
             //   var message = 'Email is used but not activated. For activation check your email.';
             //   $.toaster({ priority: priority, title: title, message: message });
});	
</script>


  </head>
  
  <body>


<div id="deleteconfirm" class="overlayfixed" style="display: none;">
						<div id="confirmBox" class="overlayContent alert">

							<h4 id="deletshowErrorMessage" >
							</h4>
							<div id="confirmButtons">
								<a id="Yes1" deleteID="" class="button blue NoShare">
									OK
								
								</a>
								<a id="No" class="button blue NoShare">
								Cancel
								
								</a>


							</div>

						</div>
					</div>
					
					
  <div class="box">
  <?php include("header.html"); ?>
        
            <div class="column col-md-12 col-sm-12 col-xs-12">
                <div class="padding">
                   
                        <!-- content -->                      
                      	<div class="row">
                          
                         <!-- main col left --> 
  <div class="col-sm-2">
                     <!--           <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/1.jpg"); ?>" class="img-responsive"></div>     
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/2.jpg"); ?>" class="img-responsive"></div>
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/3.jpg"); ?>" class="img-responsive"></div>
                            </div>-->

                        </div>
                         <div class="col-sm-8">
<!--                              <div class="well"> 
                                   <form class="form-horizontal" role="form">
                                    <h4>What's New</h4>
                                     <div class="form-group" style="padding:10px;">
                                      <textarea class="form-control" placeholder="Update your status"></textarea>
                                    </div>
                                    <button class="btn btn-info pull-right" type="button" style="">Post</button><ul class="list-inline"><li><a href=""><i class="glyphicon glyphicon-upload"></i></a></li><li><a href=""><i class="glyphicon glyphicon-camera"></i></a></li><li><a href=""><i class="glyphicon glyphicon-map-marker"></i></a></li></ul>
                                  </form>
                              </div>-->

                          <div class="row">
                              <div class="col-lg-12 appendnew" id="gallery" style="padding-right: 0px;padding-left: 0px;"></div>
<!--                            <div class="col-sm-6">

                              <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/8.jpg"); ?>" class="img-responsive"></div>
                                <div class="panel-body">
                                  <p class="lead">Urbanization</p>
                                  <p>45 Followers, 13 Posts</p>
                                  
                                  <p>
                                    <img src="https://lh3.googleusercontent.com/uFp_tsTJboUY7kue5XAsGA=s28" width="28px" height="28px">
                                  </p>
                                </div>
                              </div>

                              <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/9.jpg"); ?>" class="img-responsive"></div>
                                <div class="panel-body">
                                  <p class="lead">Urbanization</p>
                                  <p>45 Followers, 13 Posts</p>
                                  
                                  <p>
                                    <img src="https://lh3.googleusercontent.com/uFp_tsTJboUY7kue5XAsGA=s28" width="28px" height="28px">
                                  </p>
                                </div>
                              </div>

                              <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="image/10.jpg" class="img-responsive"></div>
                                <div class="panel-body">
                                  <p class="lead">Urbanization</p>
                                  <p>45 Followers, 13 Posts</p>
                                  
                                  <p>
                                    <img src="https://lh3.googleusercontent.com/uFp_tsTJboUY7kue5XAsGA=s28" width="28px" height="28px">
                                  </p>
                                </div>
                              </div>

                               <div class="panel panel-default">
                                <div class="panel-heading"><a href="#" class="pull-right">View all</a> <h4>Bootstrap Examples</h4></div>
                                  <div class="panel-body">
                                    <div class="list-group">
                                      <a href="http://bootply.com/tagged/modal" class="list-group-item">Modal / Dialog</a>
                                      <a href="http://bootply.com/tagged/datetime" class="list-group-item">Datetime Examples</a>
                                      <a href="http://bootply.com/tagged/datatable" class="list-group-item">Data Grids</a>
                                    </div>
                                  </div>
                              </div>

                           </div>

                           <div class="col-sm-6">
                              <div class="panel panel-default">
                                <div class="panel-heading"><a href="#" class="pull-right">View all</a> <h4>Bootstrap Examples</h4></div>
                                  <div class="panel-body">
                                    <div class="list-group">
                                      <a href="http://bootply.com/tagged/modal" class="list-group-item">Modal / Dialog</a>
                                      <a href="http://bootply.com/tagged/datetime" class="list-group-item">Datetime Examples</a>
                                      <a href="http://bootply.com/tagged/datatable" class="list-group-item">Data Grids</a>
                                    </div>
                                  </div>
                              </div>


                              <div class="panel panel-default">
                                <div class="panel-heading"><a href="#" class="pull-right">View all</a> <h4>Bootstrap Examples</h4></div>
                                  <div class="panel-body">
                                    <div class="list-group">
                                      <a href="http://bootply.com/tagged/modal" class="list-group-item">Modal / Dialog</a>
                                      <a href="http://bootply.com/tagged/datetime" class="list-group-item">Datetime Examples</a>
                                      <a href="http://bootply.com/tagged/datatable" class="list-group-item">Data Grids</a>
                                    </div>
                                  </div>
                              </div>
                           
                              <div class="panel panel-default">
                                 <div class="panel-heading"><a href="#" class="pull-right">View all</a> <h4>More Templates</h4></div>
                                  <div class="panel-body">
                                    <img src="//placehold.it/150x150" class="img-circle pull-right"> <a href="#">Free @Bootply</a>
                                    <div class="clearfix"></div>
                                    There a load of new free Bootstrap 3 ready templates at Bootply. All of these templates are free and don't require extensive customization to the Bootstrap baseline.
                                    <hr>
                                    <ul class="list-unstyled"><li><a href="http://www.bootply.com/templates">Dashboard</a></li><li><a href="http://www.bootply.com/templates">Darkside</a></li><li><a href="http://www.bootply.com/templates">Greenfield</a></li></ul>
                                  </div>
                              </div>

                               <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/8.jpg"); ?>" class="img-responsive"></div>
                                <div class="panel-body">
                                  <p class="lead">Urbanization</p>
                                  <p>45 Followers, 13 Posts</p>
                                  
                                  <p>
                                    <img src="https://lh3.googleusercontent.com/uFp_tsTJboUY7kue5XAsGA=s28" width="28px" height="28px">
                                  </p>
                                </div>
                              </div>
                           </div>-->
                        </div>

                          </div>

                            <div class="col-sm-2 ">
                      <!--        <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/5.jpg"); ?>" class="img-responsive"></div>     
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/6.jpg"); ?>" class="img-responsive"></div>
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-thumbnail"><img src="<?php echo base_url("image/7.jpg"); ?>" class="img-responsive"></div>
                            </div>-->
                        </div> 
                    </div>




                </div><!--/row-->

            </div><!-- /padding -->
        </div>
        <!-- /main -->

    </div>


	 <script type="text/javascript" src=<?php echo base_url("js/jquery.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/bootstrap.min.js"); ?>></script> 
    <script type="text/javascript" src=<?php echo base_url("js/jquery-1.10.2.min.js"); ?>></script>
     <script type="text/javascript" src=<?php echo base_url('js/jquery-ui.min.js'); ?>></script>
  <!--  <script type="text/javascript" src=<?php echo base_url("js/jquery.masonry.js"); ?>></script>   -->
    <script type="text/javascript" src=<?php echo base_url("js/jquery.preloader.min.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/jquery.form.min.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/scripts.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/jquery.liveurl.js"); ?>></script>
    <style>
        .preloader { background:url(<?php echo base_url . "image/728.GIF" ?>) center center no-repeat #ffffff;  }
        
        .liveurl img {
    width: 454px;
    height: 213;
    display: none;
}

.liveurl .details {
    float: left;
    overflow: hidden;
    margin: 15px;   
    word-break: break-all;
}
    </style>
    
 <script>
 $(document).ready(function() {
               
 	$("#searchbtn").click(function(){
 		var sdata = $("#countryname_1").val();
 		if(sdata == ""){
						 toastr.warning( 'Enter Search Data');
    						return false;
		}
		else{
		 window.location = "http://localhost/NewSocialUtilities/index.php/Searchresult?searchdata="+sdata;
                       	//    window.location="http://whitecode.in/demo/social_utilities/index.php/Searchresult?searchdata="+sdata;   
		}
 		
						
        });    
  });    
 </script>
 
   <script>
              
            var  Dadicatorname = null;
            var  user_id=0;
            var  Dadicator_email_id = null;
            var  Dadicateename = null;
            var  Dadicatee_email_id = null;
            var  Dedication_title = null;
            var  Dedication_City = null;
                 
            $(document).ready(function() {
               
                $("#countryname_1").each(function(i, el) {
                    el = $(el);
                    el.autocomplete({
                        source: function(request, response) {
                            var xx = request.term;
                           
                            if (xx !== '') {
                                $.ajax({
                                    url: "<?php echo base_url() . 'index.php/Welcome/GetSearchData' ?>",
                                    dataType: "json",
                                    method: 'post',
                                    data: {
                                        name_startsWith: request.term,
                                        type: 'layouts',
                                        row_num: 1
                                    },
                                    success: function(data) {
                                            
                                        response($.map(data, function(item) {
                                            var code = item.split("|");
                                          
                                            return {
                                                label: code[0],
                                                value: code[0],
                                                data: code[1]
                                            }
                                        }));
                                        var getid = el.attr('id');
                                        $(".ui-autocomplete").css("z-index", "9999999999");
                                    }
                                });
                            } else
                            {
                                $("#ui-id-1").css("display", "none");
                            }
                        },
                        	autoFocus: true,
                        	minLength: 0,
                        	select: function(event, ui) {
                            var ID = ui.item.data.split("|");
                            myFunction(ID);
                        }
                    });
                });
            });
            
            
           function myFunction(id) {
                user_id = id;
                window.location="http://localhost/NewSocialUtilities/index.php/Welcome/Singlepage?random="+user_id;
               	//  window.location="http://whitecode.in/demo/social_utilities/index.php/Welcome/Singlepage?random="+user_id;   
               
            }

</script>
    
 
    
    
    
    <script>// This Script Use For Social Plugin Facebook Comments
                                    window.fbAsyncInit = function() {
                                        FB.init({
                                            appId: '279787358834888',
                                            xfbml: true,
                                            version: 'v2.5'
                                        });
                                    };
                                    (function(d, s, id) {
                                        var js, fjs = d.getElementsByTagName(s)[0];
                                        if (d.getElementById(id)) {
                                            return;
                                        }
                                        js = d.createElement(s);
                                        js.id = id;
                                        js.src = "//connect.facebook.net/en_US/sdk.js";
                                        fjs.parentNode.insertBefore(js, fjs);
                                    }(document, 'script', 'facebook-jssdk'));</script>
<!--    <script type="text/javascript">
$(window).scroll(function()
{
    if($(window).scrollTop() == $(document).height() - $(window).height())
    {
        alert("sd");
    }
});
</script>-->
    <script type="text/javascript">
        $(document).ready(function()
        {

            function checkUrlVideo(test_url) {
                var testLoc = document.createElement('a');
                testLoc.href = test_url.toLowerCase();
                url = testLoc.hostname;
                var what;
                if (url.indexOf('youtube.com') !== -1) {
                    what = 'Youtube';
                } else if (url.indexOf('vimeo.com') !== -1) {
                    what = 'Vimeo';
                } else {
                    what = 'None';
                }
                return what;
            }

$(window).scroll(function()
{
    if($(window).scrollTop() == $(document).height() - $(window).height())
    {
        LoadMorePost();
    }
});

//            $(window).scroll(function()
//            {
//
//                var myWidth = document.body.clientWidth;
//                var myHeight = document.body.clientHeight;
//                if ($(window).scrollTop() + 1 >= $(document).height() - myHeight)
//                {
////                    LoadMorePost();
//alert("OK");
//                }
//            });
//            
//            
            // This Ajax Page Load Ajax For Load User Top Uploaded Post.
            //Start
            $.ajax({
                url: "<?php echo base_url() . 'index.php/Welcome/GetProfilePost' ?>",
                type: "POST",
                dataType: 'json',
                data: {},
                success: function(data) {
                	//alert(data);
                    window.mydata = data;
                    var record_par_page = mydata[0].Rows;
                    
                    if (data == "") {
                        //$("#LoadmOrePost_Text").html("No record found");
                        $('.appendnew').html('<h3 style="text-align: center;display: block;  height: 30px; padding-left: 110px; font-size: 44px;font-weight: 700;  text-align: center; text-decoration: none;text-shadow: 3px 1px #d9edf7;  border-radius: 2px;  color: rgb(53, 140, 234);  margin: 20px 27px -38px -45px;">No Records Found</h3>');
                    }
                    var el = "";

                    $.each(record_par_page, function(key, data) {
                        sr = (key + 1);
//                        var ShowComment = "";
//                        if (data.ShowComments == "1") {
//                            ShowComment = '<div class="fb-comments" data-href="http://localhost/facebooka/' + data.id + '" data-colorscheme="light" data-numposts="2" data-width="400"></div>';
//                        } else {
//                            ShowComment = "";
//                        }
//alert(record_par_page);
						var msg = data.Dedication_message;
						var max_length = 60;
						var ms=(data.Dedication_message).length;
						var scontentread="";
						
						if((ms)>max_length)
						{
							
							var scontent 	=msg.substr(0,max_length); /* split the content in two parts */
							var lcontent	= msg.substr(max_length);
							
								var scontentread = scontent+'<a id="readmoretag" class="a-btn" href="<?php echo base_url() . 'index.php/Welcome/Singlepage?random=' ?>' + data.id + '"><span> Read More</span></a>';                       
                               // '<span style="font-size: 14px;" class="read-more-target" id="ReadMoreContect">'+
                               // lcontent+
                              //  '</span>'+'
                              
                                 //+ 
                                //' <p for="post-1" class="read-more-trigger"></p>'; 
								
							}else{
								var scontent = msg.substr(0,max_length); /* split the content in two parts */
							
								var scontentread = scontent+'<p style="padding-bottom: 10px;"></p>';
								
							}
						var UppendImageVideoData = "";
                        var test = checkUrlVideo(data.Dedication_item);
                        if (test == "None") {
                            UppendImageVideoData = '<img class="active image' + data.id + '" src="" width="420" height="213">';
                        } else if (test == "Youtube") {
                            UppendImageVideoData = '<iframe width="450" height="213" src="' + data.Dedication_item + '" frameborder="0"></iframe>';
                        } else if (test == "Vimeo") {
                            UppendImageVideoData = '<iframe src=' + data.Dedication_item + ' width="450" height="213" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
                        }
                        
                        
                        var dn= data.Dadicatorname;
                        var dedicatorname= dn[0].toUpperCase() + dn.slice(1);
                       
                        var den= data.Dadicateename;
                        var dedicateename= den[0].toUpperCase() + den.slice(1);
                       
                        var dt= data.Dedication_title;
                        var dedicationtitle= dt[0].toUpperCase() + dt.slice(1);
                        

                         el = '<div class="col-md-6 item container" id="' + data.id + '" style="padding-left: 0px;height: 362px;margin-top: 15px;"><a href="<?php echo base_url() . 'index.php/Welcome/Singlepage?random=' ?>' + data.id + '">' +
                                '<div class="panel panel-default boxAlbum mycolor" style="padding-left: 0px;height: 372px;margin-top: 20px;">' +
                                '<a href="<?php echo base_url() . 'index.php/Welcome/Singlepage?random=' ?>' + data.id + '"><div class="col-md-12 panel_color" style="background: #FFF none repeat scroll 0% 0%;color: #000000;height: auto; margin: 0% 0% 2%;padding: 3% 0% 3% 5%;  font-weight: 700;">' +
                                 '<lable style="color: #0864C1;">' + dedicatorname + '</lable>' 
                           		 +'&nbsp;<label style="color: rgb(0, 0, 0);font-size: 12px;font-weight: 500;"> dedicated to </label>' + 
                            	 '&nbsp;<lable style="color:#0864C1;">'+ dedicateename + '</lable>' +
                            	 '<div class="btn-group show-on-hover" style="float:right;margin-right: 12px; ">'+
                                '<i class="caret dropdown-toggle" data-toggle="dropdown" style="color: blue;"></i>'+
                                '<ul class="dropdown-menu" role="menu"><li id="delete_post"><a id="' + data.id + '" class="deletePost" href="#">Delete</a></li></ul>'+
                                '</div>' +
                                '</div></a>' +
                                '<div class="col-md-12" style="display: none;">' +
                                '<textarea style="width: 300px; height: 100px;visibility: hidden;" class="textarea' + data.id + '" placeholder="write here">' +
                                data.Dedication_item +
                                '</textarea>' +
                                '</div>' +
                                '<a href="<?php echo base_url() . 'index.php/Welcome/Singlepage?random=' ?>' + data.id + '"><div class="panel-thumbnail" >' +
                                '<div class="liveurl liveurl' + data.id + '">' +
                                '<div class="inner inner' + data.id + '">' +
                                '<div class="image">' +
                                UppendImageVideoData +
                                '</div>' +
                                '<div class="details details' + data.id + '">' +
                                ' <div class="info info' + data.id + '">' +
                               // '<div class="title title' + data.id + '"> </div>' +
                                //'<div class="description description' + data.id + '"> </div>' +
                               // '<div class="url url' + data.id + '"> </div>' +
                                '</div>' +
                                '</div>' +
                                '</div>' +
                                '</div>' +
                                '</div></a>' +
                                '<a href="<?php echo base_url() . 'index.php/Welcome/Singlepage?random=' ?>' + data.id + '"><div class="panel-body">' +
                                '<p class="lead st" style="margin: 0px;font-size: 14px;font-weight: bold;">' +
                                dedicationtitle +
                                '</p>' +
                               '<p class="read-more-wrap" >' +
                                scontentread+ 
                                '</p>' + '</div></a>'+
                                '</div>'+'</a></div>'
                        $('.appendnew').append(el);
                        findUrls1('textarea' + data.id, data.id);
                        findUrls('textarea' + data.id);
                    });
                }
            });
//END OF Page Load User Post Load 

/*
function markActiveLink() {   
    alert($(this).attr("id"));
}*/


      

//This Ajax Used For Load More post
//Start
            function LoadMorePost() {
                var ID = "";
                ID = $(".appendnew").children().last().attr('id');
                /*alert(ID);*/
                $.ajax({
                    url: "<?php echo base_url() . 'index.php/Welcome/LoadMoreProfilePost' ?>",
                    type: "POST",
                    dataType: 'json',
                    data: "lastPostID=" + ID,
                    success: function(data) {
                        window.mydata = data;
                        var record_par_page = mydata[0].Rows;
                        if (data == "") {
                              $("#LoadmOrePost_Text").html("No More records found");
                        }
                        var el = "";
                        $.each(record_par_page, function(key, data) {
                            sr = (key + 1);
//                            var ShowComment = "";
//                            if (data.ShowComments == "1") {
//                                ShowComment = '<div class="fb-comments" data-href="http://localhost/facebooka/' + data.id + '" data-colorscheme="light" data-numposts="2" data-width="400"></div>';
//                            } else {
//                                ShowComment = "";
//                            }
                           var UppendImageVideoData = "";
                        var test = checkUrlVideo(data.Dedication_item);
                        if (test == "None") {
                            UppendImageVideoData = '<img class="active image' + data.id + '" src="" width="400" height="213">';
                        } else if (test == "Youtube") {
                            UppendImageVideoData = '<iframe width="450" height="213" src="' + data.Dedication_item + '" frameborder="0"></iframe>';
                        } else if (test == "Vimeo") {
                            UppendImageVideoData = '<iframe src=' + data.Dedication_item + ' width="450" height="213" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
                        }
                            
                            
                        	var msg = data.Dedication_message;
						
						var max_length = 60;
						var ms=(data.Dedication_message).length;
						var scontentread="";
						
						if((ms)>max_length)
						{
							
							var scontent 	=msg.substr(0,max_length); /* split the content in two parts */
							var lcontent	= msg.substr(max_length);
							
								var scontentread = scontent+'<a id="readmoretag" class="a-btn" href="<?php echo base_url() . 'index.php/Welcome/Singlepage?random=' ?>' + data.id + '"><span> Read More</span></a>';                       
								
							}else{
								var scontent = msg.substr(0,max_length); /* split the content in two parts */
							
								var scontentread = scontent+'<p style="padding-bottom: 10px;"></p>';
								
							}

 						var dn= data.Dadicatorname;
                        var dedicatorname= dn[0].toUpperCase() + dn.slice(1);
                       
                        var den= data.Dadicateename;
                        var dedicateename= den[0].toUpperCase() + den.slice(1);
                        
                        var dt= data.Dedication_title;
                        var dedicationtitle= dt[0].toUpperCase() + dt.slice(1);
                       
                         

                            el = '<div class="col-md-6 item" id="' + data.id + '" style="padding-left: 0px;height: 372px;margin-top: 20px;"><a href="<?php echo base_url() . 'index.php/Welcome/Singlepage?random=' ?>' + data.id + '">' +
                                    '<div class="panel panel-default boxAlbum mycolor" style="padding-left: 0px;height: 362px;margin-top: 15px;">' +
                                    '<a href="<?php echo base_url() . 'index.php/Welcome/Singlepage?random=' ?>' + data.id + '"><div class="col-md-12 panel_color"  style="background: #FFF none repeat scroll 0% 0%;color: #000000;height: auto; margin: 0% 0% 2%;padding: 3% 0% 3% 5%;  font-weight: 700;">' +
                                   
                                    '<lable style="color: #0864C1;">' + dedicatorname + '</lable>' 
                            		+'&nbsp;<label style="color: rgb(0, 0, 0);font-size: 12px;font-weight: 500;"> dedicated to </label>' + 
                           			'&nbsp;<lable style="color: #0864C1;">'+ dedicateename + '</lable>' +
                           			
                            		 '<div class="btn-group show-on-hover" style="float:right;margin-right: 12px; ">'+
                                '<i class="caret dropdown-toggle" data-toggle="dropdown" style="color: blue;"></i>'+
                                '<ul class="dropdown-menu" role="menu"><li id="delete_post"><a id="' + data.id + '" class="deletePost" href="#">Delete</a></li></ul>'//onclick="markActiveLink();"
                                +
                                //'<i class="caret dropdown-toggle" data-toggle="dropdown" style="float:right;margin-right: 12px; margin-top: 7px;"></i>'+
                                 '</div>' +
                                '</div></a>' +
                                    '<div class="col-md-12" style="display: none;">' +
                                    '<textarea style="width: 300px; height: 100px;visibility: hidden;" class="textarea' + data.id + '" placeholder="write here">' +
                                    data.Dedication_item +
                                    '</textarea>' +
                                    '</div>' +
                                    '<a href="<?php echo base_url() . 'index.php/Welcome/Singlepage?random=' ?>' + data.id + '"><div class="panel-thumbnail">' +
                                    '<div class="liveurl liveurl' + data.id + '">' +
                                    '<div class="inner inner' + data.id + '">' +
                                    '<div class="image">' +
                                    UppendImageVideoData +
                                    '</div>' +
                                    '<div class="details details' + data.id + '">' +
                                    ' <div class="info info' + data.id + '">' +
                                  //  '<div class="title title' + data.id + '"> </div>' +
                                   // '<div class="description description' + data.id + '"> </div>' +
                                  //  '<div class="url url' + data.id + '"> </div>' +
                                    '</div>' +
                                    '</div>' +
                                    '</div>' +
                                    '</div>' +
                                    '</div></a>' +
                                    '<a href="<?php echo base_url() . 'index.php/Welcome/Singlepage?random=' ?>' + data.id + '"><div class="panel-body">' +
                                    '<p class="lead st" style="margin: 0px;font-size: 14px;font-weight: bold;">' +
                                    dedicationtitle +
                                    '</p>' +
                                    '<p class="read-more-wrap" style="margin: 0px;font-size: 14px">' +
                                    scontentread+ 
                                    '</p></div></a>' +
                                    '</div>'+'</a></div>';
                            $('.appendnew').append(el);
                            findUrls1('textarea' + data.id, data.id);
                            findUrls('textarea' + data.id);
                        });
                        FB.XFBML.parse();
                       jQuery(".appendnew").masonry('reloadItems');
                    }
                });
                //$('.appendnew').masonry();
            }
//            $(document.body).on('click', '#LoadMoreClick', function(e) {
//                var ID = "";
//                ID = $(".appendnew").children().last().attr('id');
//                $.ajax({
//                    url: "<?php echo base_url() . 'index.php/Welcome/LoadMorePost' ?>",
//                    type: "POST",
//                    dataType: 'json',
//                    data: "lastPostID=" + ID,
//                    success: function(data) {
//                        window.mydata = data;
//                        var record_par_page = mydata[0].Rows;
//                        if (data == "") {
//                            $("#LoadmOrePost_Text").html("No record found");
//                        }
//                        var el = "";
//                        $.each(record_par_page, function(key, data) {
//                            sr = (key + 1);
//                            var ShowComment = "";
//                            if (data.ShowComments == "1") {
//                                ShowComment = '<div class="fb-comments" data-href="http://localhost/facebooka/' + data.id + '" data-colorscheme="light" data-numposts="2" data-width="400"></div>';
//                            } else {
//                                ShowComment = "";
//                            }
//                            el = '<div class="col-md-6 item" id="' + data.id + '" style="padding-left: 0px;">' +
//                                    '<div class="panel panel-default" >' +
//                                    '<div class="col-md-12" style="box-shadow: 5.5px 5.5px 12px -7px #B0B0B0;background: #305A63 none repeat scroll 0% 0%;color: white;height: 23px;">' +
//                                    '<lable>' +
//                                    data.Dadicatorname + ' Dedicated To ' + data.Dadicateename +
//                                    '</lable>' +
//                                    '</div>' +
//                                    '<div class="col-md-12" style="display: none;">' +
//                                    '<textarea style="width: 300px; height: 100px;visibility: hidden;" class="textarea' + data.id + '" placeholder="write here">' +
//                                    data.Dedication_item +
//                                    '</textarea>' +
//                                    '</div>' +
//                                    '<div class="panel-thumbnail">' +
//                                    '<div class="liveurl liveurl' + data.id + '">' +
//                                    '<div class="inner inner' + data.id + '">' +
//                                    '<div class="image">' +
//                                    '<img class="active image' + data.id + '" src="">' +
//                                    '</div>' +
//                                    '<div class="details details' + data.id + '">' +
//                                    ' <div class="info info' + data.id + '">' +
//                                    '<div class="title title' + data.id + '"> </div>' +
//                                    '<div class="description description' + data.id + '"> </div>' +
//                                    '<div class="url url' + data.id + '"> </div>' +
//                                    '</div>' +
//                                    '</div>' +
//                                    '</div>' +
//                                    '</div>' +
//                                    '</div>' +
//                                    '<div class="panel-body">' +
//                                    '<p class="lead" style="margin: 0px;font-size: 14px;font-weight: bold;">' +
//                                    data.Dedication_title +
//                                    '</p>' +
//                                    '<p style="margin: 0px;font-size: 13px;">' +
//                                    data.Dedication_message +
//                                    '</p>' +
//                                    '<a style="float: right;font-size: 11px;" id="ReadMore">Read More</a>' +
//                                    '</div>' +
//                                    ShowComment +
//                                    '</div>';
//                            $('.appendnew').append(el);
//
//                            findUrls1('textarea' + data.id, data.id);
//                            findUrls('textarea' + data.id);
//                        });
//                        FB.XFBML.parse();
//                        jQuery(".appendnew").masonry('reloadItems');
//                    }
//                });
//                $('.appendnew').masonry();
//            });
//END Of Load More Post
        
        });//end of document.ready()
        
        
        var name_bit = 0;
        var email_bit = 0;
        var pass_bit = 0;
        var mno_bit = 0;
        $(document).ready(function() {

//            var Text = "I'm not a very good sleeper. But you know what? https://www.youtube.com/ I'm willing to put in a few extra hours every day to get better. https://www.google.co.in/?gfe_rd=cr&ei=_COGVuuZJqyl8weiqbOwAw  That's just the kind of hard worker I am";
//         //   alert(findUrls(Text));
//
//            function findUrls(text)
//            {
//                var source = (text || '').toString();
//                var urlArray = [];
//                var url;
//                var matchArray;
//                // Regular expression to find FTP, HTTP(S) and email URLs.
//                var regexToken = /(((ftp|https?):\/\/)[\-\w@:%_\+.~#?,&\/\/=]+)|((mailto:)?[_.\w-]+@([\w][\w\-]+\.)+[a-zA-Z]{2,3})/g;
//                // Iterate through any URLs in the text.
//                while ((matchArray = regexToken.exec(source)) !== null)
//                {
//                    var token = matchArray[0];
//                    urlArray.push(token);
//                }
//                return urlArray;
//            }


            // $('.appendnew').masonry();
//            $(function() {
//                $("#gallery").preloader();
//            });

//Alignd Masonary Every 1 Min
       //     setInterval(function() {
       //         $('.appendnew').masonry();
       //     }, 5000);
//END Set Intervel



//Delete post code
$(document.body).on('click', '.deletePost', function (e) {
	$("#deleteconfirm").css('display','block');
	$("#deletshowErrorMessage").html("Are you sure you want to delete this Post?");
	 var did = $(this);
	
	 var id = did.attr('id');//alert(did);
	 //alert("ID"+id);
	  //alert($(this).attr('id'));
	 $("#Yes1").attr("deleteID",id);
	 });
	
	 
	 
	 
	 
           $("#Yes1").click(function()	
			{
              
				id=$(this).attr('deleteID');
            $.ajax({
                type: "POST",
                dataType:'json',
                url: '<?php echo base_url() . "index.php/Welcome/delete_post"; ?>',
                data: "id=" + id ,
                beforeSend: function () { },
                success: function (result) {
                	//alert(result);
                    location.reload();

                },
                error: function (data) { }
           
        });

});

	$("#No").click(function(){
				 $("#deleteconfirm").css('display', 'none');
				
				});
				
//End of delete post				

//This Ajax Use for new User Ragisterd
            $("#register_button").click(function(e) {
            	
                if (email_bit == 1 && mno_bit == 1) {
                    $.ajax({
                        url: '<?php echo base_url() . "index.php/Welcome/register_database"; ?>',
                        type: "POST",
                        data: $('#register_form').serialize(),
                        cache: false,
                        beforeSend: function()
                        {
                        },
                        success: function(response) {
                        	 $("#register_form")[0].reset(); 
                             $("#msg").html(response);
                             location.reload();
                        }
                    })
                } else {
                    document.getElementById('msg').innerHTML = "Please check your details";
                }
                e.preventDefault();
            }); //on click form submit
//END New User Ragister

//This Ajax Used For User Login
		$("#loginpass").keypress(function (e){
                if (e.keyCode == 13) {
                	 var wrong = "Your account not activated. check your mail and activate your account.";
                var check = "Wrong credentials";
                var check2="Please Enter All Fields";
                $.ajax({
                    url: '<?php echo base_url() . "index.php/Welcome/login_check"; ?>',
                    type: "POST",
                    data: $('#login_form').serialize(),
                    cache: false,
                    beforeSend: function()
                    {
                    },
                    success: function(response) {
                        $("#login_form")[0].reset(); 
                        if (response == 0) {
                            $("#msg1").html(wrong);
                        } else if (response == 2) {
                            $("#msg1").html(check);
                        }
                        else if (response == 1) {
                            window.location = "http://localhost/NewSocialUtilities/";
                        		// window.location = "http://whitecode.in/demo/social_utilities/";
                        }
                         else if(response == -1){
							$("#msg1").html(check2);
						}
                    }
                });
                 e.preventDefault();
                }
              });
                
            $("#login_button").click(function() {
                var wrong = "Your account not activated. check your mail and activate your account.";
                var check = "Wrong credentials";
                var check2="Please Enter All Fields";
                $.ajax({
                    url: '<?php echo base_url() . "index.php/Welcome/login_check"; ?>',
                    type: "POST",
                    data: $('#login_form').serialize(),
                    cache: false,
                    beforeSend: function()
                    {
                    },
                    success: function(response) {
                        $("#login_form")[0].reset(); 
                        if (response == 0) {
                            $("#msg1").html(wrong);
                        } else if (response == 2) {
                            $("#msg1").html(check);
                        }
                        else if (response == 1) {
                            window.location = "http://localhost/NewSocialUtilities/";
                        		// window.location = "http://whitecode.in/demo/social_utilities/";
                        }
                         else if(response == -1){
							$("#msg1").html(check2);
						}
                    }
                });
            }); //on click form submit
//END OF Login
      
  //code for forgot passward  
     $("#forgot_pass_button").click(function(e) {
                 
            var email = document.getElementById("fpemailid").value;
            var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
            if(email==''){
				 document.getElementById('msg2').innerHTML = "Enter email address" 
			}else if (emailReg.test(email) == false) {
               email_bit = 0;
                document.getElementById('msg2').innerHTML = "Invalid email address"
                return false;
               
            }else if (emailReg.test(email) == true) {
                email_bit = 1;
                 document.getElementById('msg2').innerHTML = ""
                
            }

       
                $.ajax({
                    url: '<?php echo base_url() . "index.php/Welcome/forgot_pass_check"; ?>',
                    type: "POST",
                    data: $('#forgot_pass_form').serialize(),
                    cache: false,
                    beforeSend: function()
                    {
                    	
                    },
                    success: function(response) {
                                                 $("#forgot_pass_form")[0].reset(); 
						alert(response);  
						 
						 if(response==1){ 
						 				//alert("sdfsf"); 
						 				// e.preventDefault();     
						 				// return true;
						 				//window.location.href;
						 				
						 }else  if(response==0){
						 			 	document.getElementById('msg2').innerHTML = "Please Enter Your Email Id";
						 			 	// e.preventDefault();     
						 				// return false;
						 			 	
               			 }else  if(response==2){
						 			 	document.getElementById('msg2').innerHTML = "You are not an registered user please register.";
               			 }
                               
                    }
                
                });
            //on click form submit
//END OF Forgot Password   
  
        });
        
        
        
        
        
        
   });       
        
   function countChar1(val) {
   			var textbox = document.getElementById("rname").value;
           
            if (textbox.length < 2) {
                name_bit = 0;
                 document.getElementById('msg').innerHTML =  "Enter characters of minimum length 3"
              //   document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
            //     document.getElementById('mno').disabled = true;
            //     document.getElementById('uemail').disabled = true;
             //    document.getElementById('pass').disabled = true;
            } else {
            	 
                 document.getElementById('msg').innerHTML = ""
                 document.getElementById('msgpop').innerHTML =  ""
           //      document.getElementById('mno').disabled = false;
           //      document.getElementById('uemail').disabled = false;
           //      document.getElementById('pass').disabled = false;
                 name_bit = 1;
            }
            
             val = (val) ? val : window.event;
            var charCode = (val.which) ? val.which : val.keyCode;
              if((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 122)||(charCode === 8)||(charCode=== 32)||(charCode===39)){
              	
                return true;
            }
            return false;
        }

       
        function countmobile(evt) {
            var textbox = document.getElementById("mno").value;
            if (textbox.length < 9) {

                document.getElementById('msg').innerHTML = "Enter a 10 digit Phone no."
             //   document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
             ////    document.getElementById('rname').disabled = true;
              //  document.getElementById('uemail').disabled = true;
              //  document.getElementById('pass').disabled = true;
                //  document.getElementById('cpass').disabled = true;
                mno_bit = 0;
            } else if (textbox.length > 10) {
                document.getElementById('msg').innerHTML = "Enter a 10 digit Phone no."
                //document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
              //   document.getElementById('rname').disabled = true;
             //   document.getElementById('uemail').disabled = true;
             //   document.getElementById('pass').disabled = true;
                // document.getElementById('cpass').disabled = true;
                mno_bit = 0;
            } else {
                document.getElementById('msg').innerHTML = ""
                document.getElementById('msgpop').innerHTML =  ""
              //  document.getElementById('rname').disabled = false;
             //   document.getElementById('uemail').disabled = false;
             //   document.getElementById('pass').disabled = false;
                mno_bit = 1;
            }

            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }



		 

        function validateEmail() {
            var email = document.getElementById("uemail").value;
           var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,3})?$/;
            if (emailReg.test(email) == false) {
                email_bit = 0;
                document.getElementById('msg').innerHTML = "Invalid email address"
               // document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
               // document.getElementById('rname').disabled = true;
               // document.getElementById('mno').disabled = true;
               // document.getElementById('pass').disabled = true;
            } else {
                 email_bit = 1;
                 document.getElementById('msg').innerHTML = ""
                 document.getElementById('msgpop').innerHTML =  ""
                // document.getElementById('rname').disabled = false;
                // document.getElementById('mno').disabled = false;
                 //document.getElementById('pass').disabled = false;
            }

        }


        function checkPwd(val) {

            var str = document.getElementById("pass").value;
            
            if ((str.length < 4)) {
                document.getElementById('msg').innerHTML = "Password must have min 4 character "
                pass_bit = 1;
           
            }else{
				 document.getElementById('msg').innerHTML = ""
                pass_bit = 0;
			}
                
        }



    </script>
    <script>

        var curImages = new Array();
        function findUrls(text)
        {
            $('.' + text).trigger('keyup');
        }
        function findUrls1(text, id)
        {
            $('.' + text).liveUrl({
                loadStart: function() {
                },
                loadEnd: function() {
                },
                success: function(data)
                {
                    var output = $('.liveurl' + id);
                    output.find('.title' + id).text(data.title);
                    output.find('.description' + id).text(data.description);
                    var URL = '<a href="' + data.url + '" target="_blank">' + data.url + '</a>'
                    output.find('.url' + id).html(URL);
                    output.find('.image' + id).empty();
                    output.show('fast');



                },
                addImage: function(image)
                {
                    var output = $('.liveurl' + id);
                    var jqImage = $(image);
                    var newimage = jqImage.attr('src');
                    output.find('.image' + id).attr('src', newimage);
                    $('.appendnew').imagesLoaded(function() {
                        $("#gallery").preloader();
                        $('.appendnew').masonry();
                    });
                }
            });
        }
    </script>
</body>
</html>