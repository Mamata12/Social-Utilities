<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title></title>
<meta name="" content="">

</head>
<body>
  <nav class="navbar navbar-default navbar-fixed-top">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                                             
                        <a href="<?php echo base_url() ?>" class="logo">Social Utility</a> 
                        
                    </div><!--navbar header-->

                    <div class="search">
                        <div class="input-group">
                           <input type="text" id="countryname_1" name="countryname[]" class="form-control countryname_1" placeholder="Dedicator's Name, Dedicatee Name, etc">
                            <span class="input-group-btn">
                                <button class="btn btn-default" id="searchbtn" type="button"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
                            </span>
                        </div><!-- /input-group -->
                    </div>
			
                     <div id="navbar" class="navbar-collapse collapse mymenu1">
                     
                        <ul class="nav navbar-nav">
							
                      
                                <li >
                                <?php echo "<span style='color: #fff' class='profile_name'>Welcome ! <em>".$user_profile['name']."</em></span>"; ?>
                               
                                       <?php echo "<a style='color: #fff' href='?logout=yes'>Logout</a>"; ?>
                             
								
                                </li> 
                          
                        </ul>
                    </div>
                </div>
            </nav>

</body>
</html>