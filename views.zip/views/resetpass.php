<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title>Social Utility | Home</title>
        <meta name="generator" content="Bootply" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        
        
         <link href=<?php echo base_url("//code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" ); ?>  rel="stylesheet" />
        
	    <link href=<?php echo base_url("css/bootstrap.min.css"); ?> rel='stylesheet' type='text/css' />
        <link href=<?php echo base_url("css/4-col-portfolio.css"); ?> rel='stylesheet' type='text/css' />
        <!--[if lt IE 9]>
                <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <link href=<?php echo base_url("css/styles.css"); ?> rel='stylesheet' type='text/css' />
        <link href=<?php echo base_url("css/liveurl.css"); ?> rel='stylesheet' type='text/css' />
		
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
 <link href=<?php echo base_url("css/toastr.css"); ?> rel='stylesheet' type='text/css' />
<link href=<?php echo base_url("css/hover.css"); ?> rel='stylesheet' type='text/css' />
<script type="text/javascript" src=<?php echo base_url("js/jquery.min.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/jquery-ui.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/jquery.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/toastr.js"); ?>></script>


<link href=<?php echo base_url("tooltipstyles.css"); ?> rel='stylesheet' type='text/css' />
<link href=<?php echo base_url("css/jquery-ui.min.css"); ?> rel='stylesheet' type='text/css' />

<style>
.popover{
    width:200px;
    height:250px;  
}</style> 

<script>
$(document).ready(function(){
				//toastr.success('Are you the six fingered man?', 'Inigo Montoya');
				//var priority = 'danger';
             //   var title = '';
             //   var message = 'Email is used but not activated. For activation check your email.';
             //   $.toaster({ priority: priority, title: title, message: message });
});	
</script>

 </head>
    <body>
   
                   <?php include("header.html"); ?>
                     <h4 class="modal-title" style="height: 30px;
    padding-left: 110px;
    font-size: 44px;
    font-weight: 700;
    text-align: center;
    text-decoration: none;
    text-shadow: 3px 1px #d9edf7;
    border-radius: 2px;
    color: rgb(53, 140, 234);
    margin: 20px 27px -38px -45px;">Reset Password</h4>
               
               <div class="col-md-4"></div>    
            <div class="column col-md-4" >
              
                <div class="padding">       
                            <div class="account-form">
                	<form id="forgot_pass_form" method="post">
						<center>
						 <ul class="form-list">
                            <li >
                           <div style="padding-left:8px;">
										<input type="password"  id="pass" class="input-text" name="pass"  placeholder="Enter Password">
							</div>	
							</li>	
							 <li > 
							  <div style="padding-left:8px;">
										<input type="password"  id="cpassword" class="input-text" name="cfpass"  placeholder="Re-Enter Your Password">
								</div>	
							</li>	
							 <li >
							  <div style="padding-left:8px;">
                            			<span id="msg"></span>
                              </div>	
                            </li>
                        
							 <li > 		
							   <div >
										 <button class="btn btn-info hvr-sweep-to-right" id="reset_password_button" type="submit" ><span>Submit</span></button>
								 </div>	
							</li>
						</ul>	
						</center>			
						</form>
					</div>	
				 </div> 
           </div> 
          <div class="col-md-4"></div>   
      
       <!-- log in -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content" >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style="text-align: center;text-decoration: underline;">LogIn</h4>
                </div>

                <div class="account-form">
                    <form method="post" id="login_form" class="form-login">

                        <ul class="form-list row">
                            <li class="col-md-12 col-sm-12"> 
                                <button type="button" class="btn btn-primary btn-lg" >Sign In With Facebook</button>
                            </li>
                            <li class="col-md-12 col-sm-12"> 
                                <button type="button" class="btn btn-danger btn-lg">Sign In With Twitter</button>
                            </li>
                            <li class="col-md-12 col-sm-12">

                                <input required type="text" name="username" class="input-text" placeholder="User Name or Email">
                            </li>
                            <li class="col-md-12 col-sm-12">

                                <input required type="password" name="pass" class="input-text" placeholder="Password" id="loginpass">
                            </li> 
                             <li class="col-md-6 col-sm-12 pwd text-right" style="float: right; ">
                                <p style="float:right;" style="color: #46b8da;padding-right: 26px;"> <a href="#" data-toggle="modal" data-target="#ChangePasswordModal"> Change Password? </a> </p>  
                                 <p style="float:right;" style="color: #46b8da;padding-right: 26px;"> <a href="#" data-toggle="modal" data-target="#ForgotPassModal"> Forgot Password? </a> </p>                                                  		
                            </li>

                            <li class="col-md-12 col-sm-12">
                           <span id="msg1"></span>
                           </li>
                        </ul>
                        <div class="buttons-set" style="padding-top:20px">
                         
                            <button type="button" class="btn btn-info" id="login_button" type="submit" style="width: 25%;
                                    margin-top: -45px;;margin-left: 56px;"><span>Login</span></button>
                        </div>
                    </form>
                </div> 

            </div>

        </div>
    </div>

    <!-- sign up -->
    <div class="modal fade" id="myModal1" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content" >
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" style="text-align:center;text-decoration: underline;">Sign-Up </h4>
                </div>
                <div class="account-form">                        
                    <form method="post" class="form-login" id="register_form">
                        <ul class="form-list row">

                            <li class="col-md-12 col-sm-12">

                                <input  type="text" class="input-text" placeholder="Full Name *" id="rname" onkeypress="return countChar1(event)"  name="fullname" required>
                            </li>
                            <li class="col-md-12 col-sm-12">

                                <input  type="text" class="input-text" placeholder="Email Address *" id="uemail" onkeypress="validateEmail();"  name="email" required>
                            </li> 
                            <li class="col-md-12 col-sm-12">

                                <input  type="text" class="input-text" placeholder="Contact Number *" id="mno" maxlength="10"   onkeypress="return countmobile(event)" name="mno" required>
                            </li> 
                            <li class="col-md-12 col-sm-12">

                                <input  type="password" class="input-text" placeholder="Password *"  onkeypress="return checkPwd(event)" id="pass" name="pass" required>
                            </li>
                            <li class="col-md-12 col-sm-12">                                                
                                <span ><input class="input-chkbox" type="checkbox" style="width: 3.5%;"></span>
                                <p style=" margin-top: -38px;margin-left: 17px;">Accept Terms and Conditions</p>
                            </li>
                            <span id="msg"></span> <br>
                            <span id="msgpop"></span> 
                        </ul>
                        <div class="buttons-set">
                            <button type="submit"  class="btn btn-info submit" id="register_button" onc  style="width: 25%; 
                                    margin-top: 5px;margin-left: 56px;margin-bottom: 20px;">Register</button>
                        </div>
                    </form>
                </div> 
            </div>

        </div>
    </div>


    <!-- script references -->
<!--    <script src=<?php //echo base_url("js/jquery-1.7.js");                            ?>></script>-->
<!--    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>-->
     <script type="text/javascript" src=<?php echo base_url("js/jquery.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/bootstrap.min.js"); ?>></script> 
    <script type="text/javascript" src=<?php echo base_url("js/jquery-1.10.2.min.js"); ?>></script>
        <script type="text/javascript" src=<?php echo base_url('js/jquery-ui.min.js'); ?>></script>
  <!--  <script type="text/javascript" src=<?php echo base_url("js/jquery.masonry.js"); ?>></script>   -->
    <script type="text/javascript" src=<?php echo base_url("js/jquery.preloader.min.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/jquery.form.min.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/scripts.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/jquery.liveurl.js"); ?>></script>
  
    <style>
        .preloader { background:url(<?php echo base_url . "image/728.GIF" ?>) center center no-repeat #ffffff;  }
        
        
    </style>
 
 <script>
 $(document).ready(function() {
               
 	$("#searchbtn").click(function(){
 		var sdata = $("#countryname_1").val();
 		if(sdata == ""){
						 toastr.warning( 'Enter Search Data');
    						return false;
		}
		else{
			  window.location = "http://localhost/NewSocialUtilities/index.php/Searchresult?searchdata="+sdata;
                 //         window.location="http://whitecode.in/demo/social_utilities/index.php/Searchresult?searchdata="+sdata;   
		}
 		
						
        });    
  });    
 </script>
 
  <script>
              
            var  Dadicatorname = null;
            var  user_id=0;
            var  Dadicator_email_id = null;
            var  Dadicateename = null;
            var  Dadicatee_email_id = null;
            var  Dedication_title = null;
            var  Dedication_City = null;
                 
            $(document).ready(function() {
               
                $("#countryname_1").each(function(i, el) {
                    el = $(el);
                    el.autocomplete({
                        source: function(request, response) {
                            var xx = request.term;
                           
                            if (xx !== '') {
                                $.ajax({
                                    url: "<?php echo base_url() . 'index.php/Welcome/GetSearchData' ?>",
                                    dataType: "json",
                                    method: 'post',
                                    data: {
                                        name_startsWith: request.term,
                                        type: 'layouts',
                                        row_num: 1
                                    },
                                    success: function(data) {
                                            
                                        response($.map(data, function(item) {
                                            var code = item.split("|");
                                          
                                            return {
                                                label: code[0],
                                                value: code[0],
                                                data: code[1]
                                            }
                                        }));
                                        var getid = el.attr('id');
                                        $(".ui-autocomplete").css("z-index", "9999999999");
                                    }
                                });
                            } else
                            {
                                $("#ui-id-1").css("display", "none");
                            }
                        },
                        	autoFocus: true,
                        	minLength: 0,
                        	select: function(event, ui) {
                            var ID = ui.item.data.split("|");
                            myFunction(ID);
                        }
                    });
                });
                
  
     
                
                
                
            });
            
            
           function myFunction(id) {
                user_id = id;
                window.location="http://localhost/NewSocialUtilities/index.php/Welcome/Singlepage?random="+user_id;
                // window.location="http://whitecode.in/demo/social_utilities/index.php/Welcome/Singlepage?random="+user_id; 
            }

</script>
    
    
 <script>

       $(document).ready(function(){
       	
		var myValue = ' <?php print_r($email);?>';
		//alert(myValue);
       	
          $("#reset_password_button").click(function(e){
          			
          			var pass=$("#pass").val();
          		var cpass=$("#cpassword").val();
          			
          			var email= myValue;          			
          			if(pass==cpass){				
                			 $.ajax({
          			 	 url: '<?php echo base_url() . "index.php/Resetpass/reset_pass"; ?>',
          			         type: "POST",
                   		         data: {
                           				'email':email,
                				        'cpass':cpass
                			  },
                		         cache: false,
                            		 beforeSend: function()
                                    {
                        	
                                     },
                		success: function(response) {
                                  $("#forgot_pass_form")[0].reset(); 
                			
                			if(response == "1"){
										 alert("Password changed Successfully");
							}else if(response == "0"){
										alert("Somthing Went Wrong");
							}
                 		}
          				
           			})
          				
			     }else{
						 toastr.warning( 'Password Missmatch');
    				 	         return false;
				}
          		e.preventDefault();	
          		});
          		
          	});
     
     
      var name_bit = 0;
        var email_bit = 0;
        var pass_bit = 0;
        var mno_bit = 0;
        $(document).ready(function() {

//            var Text = "I'm not a very good sleeper. But you know what? https://www.youtube.com/ I'm willing to put in a few extra hours every day to get better. https://www.google.co.in/?gfe_rd=cr&ei=_COGVuuZJqyl8weiqbOwAw  That's just the kind of hard worker I am";
//         //   alert(findUrls(Text));
//
//            function findUrls(text)
//            {
//                var source = (text || '').toString();
//                var urlArray = [];
//                var url;
//                var matchArray;
//                // Regular expression to find FTP, HTTP(S) and email URLs.
//                var regexToken = /(((ftp|https?):\/\/)[\-\w@:%_\+.~#?,&\/\/=]+)|((mailto:)?[_.\w-]+@([\w][\w\-]+\.)+[a-zA-Z]{2,3})/g;
//                // Iterate through any URLs in the text.
//                while ((matchArray = regexToken.exec(source)) !== null)
//                {
//                    var token = matchArray[0];
//                    urlArray.push(token);
//                }
//                return urlArray;
//            }


            // $('.appendnew').masonry();
//            $(function() {
//                $("#gallery").preloader();
//            });

//Alignd Masonary Every 1 Min
         //   setInterval(function() {
      //          $('.appendnew').masonry();
       //     }, 1500);
//END Set Intervel


//This Ajax Use for new User Ragisterd
            $("#register_button").click(function(e) {
            	
                if (email_bit == 1 && mno_bit == 1) {
                    $.ajax({
                        url: '<?php echo base_url() . "index.php/Welcome/register_database"; ?>',
                        type: "POST",
                        data: $('#register_form').serialize(),
                        cache: false,
                        beforeSend: function()
                        {
                        },
                        success: function(response) {
                        	 $("#register_form")[0].reset(); 
                             $("#msg").html(response);
                             location.reload();
                        }
                    })
                } else {
                    document.getElementById('msg').innerHTML = "Please Enter your details";
                }
                e.preventDefault();
            }); //on click form submit
//END New User Ragister

//This Ajax Used For User Login
		$("#loginpass").keypress(function (e){
                if (e.keyCode == 13) {
                	 var wrong = "Your account not activated. check your mail and activate your account.";
                var check = "Wrong credentials";
                var check2="Please Enter All Fields";
                $.ajax({
                    url: '<?php echo base_url() . "index.php/Welcome/login_check"; ?>',
                    type: "POST",
                    data: $('#login_form').serialize(),
                    cache: false,
                    beforeSend: function()
                    {
                    },
                    success: function(response) {
                                $("#login_form")[0].reset(); 
                       alert(response);
                        if (response == 0) {
                            $("#msg1").html(wrong);
                        } else if (response == 2) {
                            $("#msg1").html(check);
                        }
                        else if (response == 1) {
                            window.location = "http://localhost/NewSocialUtilities/";
                        	//window.location = "http://whitecode.in/demo/social_utilities/";
                        }
                         else if(response == -1){
							$("#msg1").html(check2);
						}
                    }
                });
                 e.preventDefault();
                }
              });
                
            $("#login_button").click(function() {
            	
                var wrong = "Your account not activated. check your mail and activate your account.";
                var check = "Wrong credentials";
                var check2="Please Enter All Fields";
                $.ajax({
                    url: '<?php echo base_url() . "index.php/Welcome/login_check"; ?>',
                    type: "POST",
                    data: $('#login_form').serialize(),
                    cache: false,
                    beforeSend: function()
                    {
                    },
                    success: function(response) {
                              $("#login_form")[0].reset(); 
                       alert(response);
                        if (response == 0) {
                            $("#msg1").html(wrong);
                        } else if (response == 2) {
                            $("#msg1").html(check);
                        }
                        else if (response == 1) {
                            window.location = "http://localhost/NewSocialUtilities/";
                        	//window.location = "http://whitecode.in/demo/social_utilities/";
                        }
                         else if(response == -1){
							$("#msg1").html(check2);
						}
                    }
                });
            }); //on click form submit
//END OF Login
      
  //code for forgot passward  
     $("#forgot_password_button").click(function(e) {
            
            var email = document.getElementById("fpemailid").value;
            var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
            if(email==''){
				 document.getElementById('msg2').innerHTML = "Enter email address" 
			}else if (emailReg.test(email) == false) {
               email_bit = 0;
                document.getElementById('msg2').innerHTML = "Invalid email address"
                return false;
               
            }else if (emailReg.test(email) == true) {
                email_bit = 1;
                 document.getElementById('msg2').innerHTML = ""
                
            }

       
                $.ajax({
                    url: '<?php echo base_url() . "index.php/Welcome/forgot_pass_check"; ?>',
                    type: "POST",
                    data: $('#forgot_pass_form').serialize(),
                    cache: false,
                    beforeSend: function()
                    {
                    	
                    },
                    success: function(response) {
                                           $("#forgot_pass_form")[0].reset(); 
						alert(response);  
						 
						 if(response==1){ 
						 				//alert("sdfsf"); 
						 				// e.preventDefault();     
						 				// return true;
						 				//window.location.href;
						 				
						 }else  if(response==0){
						 			 	document.getElementById('msg2').innerHTML = "Please Enter Your Email Id";
						 			 	// e.preventDefault();     
						 				// return false;
						 			 	
               			 }else  if(response==2){
						 			 	document.getElementById('msg2').innerHTML = "You are not an registered user please register.";
               			 }
                               
                    }
                
                });
            //on click form submit
//END OF Forgot Password   
  
        });
        
        
        
        
        
        
   });       
        
   function countChar1(val) {
   			var textbox = document.getElementById("rname").value;
           
            if (textbox.length < 2) {
                name_bit = 0;
                 document.getElementById('msg').innerHTML =  "Enter characters of minimum length 3"
              //   document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
            //     document.getElementById('mno').disabled = true;
            //     document.getElementById('uemail').disabled = true;
             //    document.getElementById('pass').disabled = true;
            } else {
            	 
                 document.getElementById('msg').innerHTML = ""
                 document.getElementById('msgpop').innerHTML =  ""
           //      document.getElementById('mno').disabled = false;
           //      document.getElementById('uemail').disabled = false;
           //      document.getElementById('pass').disabled = false;
                 name_bit = 1;
            }
            
             val = (val) ? val : window.event;
            var charCode = (val.which) ? val.which : val.keyCode;
              if((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 122)||(charCode === 8)||(charCode=== 32)||(charCode===39)){
              	
                return true;
            }
            return false;
        }

       
        function countmobile(evt) {
            var textbox = document.getElementById("mno").value;
            if (textbox.length < 9) {

                document.getElementById('msg').innerHTML = "Enter a 10 digit Phone no."
             //   document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
             ////    document.getElementById('rname').disabled = true;
              //  document.getElementById('uemail').disabled = true;
              //  document.getElementById('pass').disabled = true;
                //  document.getElementById('cpass').disabled = true;
                mno_bit = 0;
            } else if (textbox.length > 10) {
                document.getElementById('msg').innerHTML = "Enter a 10 digit Phone no."
                //document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
              //   document.getElementById('rname').disabled = true;
             //   document.getElementById('uemail').disabled = true;
             //   document.getElementById('pass').disabled = true;
                // document.getElementById('cpass').disabled = true;
                mno_bit = 0;
            } else {
                document.getElementById('msg').innerHTML = ""
                document.getElementById('msgpop').innerHTML =  ""
              //  document.getElementById('rname').disabled = false;
             //   document.getElementById('uemail').disabled = false;
             //   document.getElementById('pass').disabled = false;
                mno_bit = 1;
            }

            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }



		 

        function validateEmail() {
            var email = document.getElementById("uemail").value;
           var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,3})?$/;
            if (emailReg.test(email) == false) {
                email_bit = 0;
                document.getElementById('msg').innerHTML = "Invalid email address"
               // document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
               // document.getElementById('rname').disabled = true;
               // document.getElementById('mno').disabled = true;
               // document.getElementById('pass').disabled = true;
            } else {
                 email_bit = 1;
                 document.getElementById('msg').innerHTML = ""
                 document.getElementById('msgpop').innerHTML =  ""
                // document.getElementById('rname').disabled = false;
                // document.getElementById('mno').disabled = false;
                 //document.getElementById('pass').disabled = false;
            }

        }


        function checkPwd(val) {

            var str = document.getElementById("pass").value;
            
            if ((str.length < 4)) {
                document.getElementById('msg').innerHTML = "Password must have min 4 character "
                pass_bit = 1;
           
            }else{
				 document.getElementById('msg').innerHTML = ""
                pass_bit = 0;
			}
                
        }



    </script>
    <script>

        var curImages = new Array();
        function findUrls(text)
        {
            $('.' + text).trigger('keyup');
        }
        function findUrls1(text, id)
        {
            $('.' + text).liveUrl({
                loadStart: function() {
                },
                loadEnd: function() {
                },
                success: function(data)
                {
                    var output = $('.liveurl' + id);
                    output.find('.title' + id).text(data.title);
                    output.find('.description' + id).text(data.description);
                    var URL = '<a href="' + data.url + '" target="_blank">' + data.url + '</a>'
                    output.find('.url' + id).html(URL);
                    output.find('.image' + id).empty();
                    output.show('fast');



                },
                addImage: function(image)
                {
                    var output = $('.liveurl' + id);
                    var jqImage = $(image);
                    var newimage = jqImage.attr('src');
                    output.find('.image' + id).attr('src', newimage);
                    $('.appendnew').imagesLoaded(function() {
                        $("#gallery").preloader();
                        $('.appendnew').masonry();
                    });
                }
            });
        }
    </script>
</body>
</html>