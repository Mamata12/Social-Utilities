<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title>Social Utility | Edit Profile</title>
        <meta name="generator" content="Bootply" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        
        
         <link href=<?php echo base_url("//code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" ); ?>  rel="stylesheet" />
        
	    <link href=<?php echo base_url("css/bootstrap.min.css"); ?> rel='stylesheet' type='text/css' />
        <link href=<?php echo base_url("css/4-col-portfolio.css"); ?> rel='stylesheet' type='text/css' />
        <!--[if lt IE 9]>
                <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <link href=<?php echo base_url("css/styles.css"); ?> rel='stylesheet' type='text/css' />
        <link href=<?php echo base_url("css/liveurl.css"); ?> rel='stylesheet' type='text/css' />
		
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
 <link href=<?php echo base_url("css/toastr.css"); ?> rel='stylesheet' type='text/css' />
<link href=<?php echo base_url("css/hover.css"); ?> rel='stylesheet' type='text/css' />
<script type="text/javascript" src=<?php echo base_url("js/jquery.min.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/jquery-ui.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/jquery.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/toastr.js"); ?>></script>


<link href=<?php echo base_url("tooltipstyles.css"); ?> rel='stylesheet' type='text/css' />
<link href=<?php echo base_url("css/jquery-ui.min.css"); ?> rel='stylesheet' type='text/css' />

<style>
.popover{
    width:200px;
    height:250px;  
}</style> 

<script>

 function validateEmail() {
            var email = document.getElementById("Email").value;
            var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
            if(email.match(emailReg)){
            	
              			return true;
            } else {
                     toastr.warning( 'Enter Valid Email Id ');
    				 return false;
            }

        }
$(document).ready(function(){
				//toastr.success('Are you the six fingered man?', 'Inigo Montoya');
				//var priority = 'danger';
             //   var title = '';
             //   var message = 'Email is used but not activated. For activation check your email.';
             //   $.toaster({ priority: priority, title: title, message: message });
});	
</script>

 </head>
    <body>
   

             <?php include("header.html"); ?>
             <div class="col-md-4"></div>  
             
              <h4 class="modal-title" style="text-align: center;display: block;  height: 30px; padding-left: 110px; font-size: 44px;font-weight: 700;  text-align: center; text-decoration: none;text-shadow: 3px 1px #d9edf7;  border-radius: 2px;  color: rgb(53, 140, 234);  margin: 20px 27px -38px -45px;">Edit Profile</h4>
                <div class="column col-md-4" ></div>
               
            <div class="column col-md-4" >
              
                <div class="padding">       
                   
                <div class="account-form">
                                
						<form id="edit_profile_form" method="post">
						<center>
						 <ul >
                            <li >
                           <div style="padding-left:8px;">
										<input type="text"  id="Name" class="input-text" name="name"  value=" <?php echo $name=$profile['fullname'];?>">
										<input type="hidden"  id="Name" class="input-text" name="name"  value=" <?php echo $name=$profile['id'];?>">
							</div>	
							</li>
							 <li><div style="padding-left:8px;">
										<input type="text"  id="Email" class="input-text" name="email"  value=" <?php  $email = $profile['email']; echo $email?> ">
							</div>	
							</li>
							 <li><div style="padding-left:8px;">
										<input type="text"  id="Contact" class="input-text" maxlength="10" name="contact"  value=" <?php  $contact = $profile['mobile']; echo $contact?>">
							</div>	
							</li>
							
							 <li > 
							  <div style="padding-left:8px;">
										<input type="password"  id="password" class="input-text" name="pass"  value="<?php  $pass = $profile['password']; echo $pass?>"><br>
								</div>	
							</li>	
							 <li >
							  <div style="padding-left:8px;">
                            			<span id="msg"></span>
                              </div>	
                            </li>
                        
							 <li > 		
							   <div >
									 <button class="btn btn-info hvr-sweep-to-right" id="edit_button" style="margin-left: 12px;" type="submit" >Submit</button>
							   </div>	
							</li>
						</ul>	
						</center>			
						</form>
					</div>	
				 </div> 
           </div> 
          <div class="col-md-4">
          	
          <!--   <?php $name = $profile['fullname'];  echo $name;?>
             <?php  $email = $profile['email']; echo $email?>
             <?php  $contact = $profile['mobile']; echo $contact?>
             <?php  $pass = $profile['password']; echo $pass?>
       -->
          </div>   
      
 <script>

       $(document).ready(function(){
       	
    
		var myValue = ' <?php print_r($uid);?>';
		
          		$("#edit_button").click(function(){
          			
          			var name1 = $("#Name").val();
          			var email1 = $("#Email").val();
          			var contact1 = $("#Contact").val();
          			var pass1 = $("#password").val();
          			
          			var name = name1.trim();
          			var email = email1.trim();
          			var contact =  contact1.trim();
          			var pass = pass1.trim();
          			
          			var id= myValue;
          			
          			
          			//alert(id);
          			
          			 $.ajax({
          			 	url: '<?php echo base_url() . "index.php/Editprofile/edit"; ?>',
          			    type: "POST",
                   		data: {
                				'id':id,
                				'name':name,
                				'email':email,
                				'contact':contact,
                				'pass':pass
                			  },
                		cache: false,
                		 beforeSend: function()
                        {
                        	//alert("heyyyyy");
                        },
                		success: function(response) {
                                    $("#edit_profile_form")[0].reset();   
                			//alert("hieeeeeeeeeeeeeeeeeeee");
                			toastr.success('Updated Successfully.......');
                			 
                			
                			
                		}
          				
          			})
          			
          		});
            });		
 
 </script>
 <script>
 	$(document).ready(function() {
               
 	$("#searchbtn").click(function(){
 		var sdata = $("#countryname_1").val();
 		if(sdata == ""){
						 toastr.warning( 'Enter Search Data');
    						return false;
		}
		else{
			  window.location = "http://localhost/NewSocialUtilities/index.php/Searchresult?searchdata="+sdata;
                      //    window.location="http://whitecode.in/demo/social_utilities/index.php/Searchresult?searchdata="+sdata;   
		}
 		
						
        });    
  });	
 	
 </script>
  <script>
  
              
            var  Dadicatorname = null;
            var  user_id=0;
            var  Dadicator_email_id = null;
            var  Dadicateename = null;
            var  Dadicatee_email_id = null;
            var  Dedication_title = null;
            var  Dedication_City = null;
                 
            $(document).ready(function() {
               
                $("#countryname_1").each(function(i, el) {
                    el = $(el);
                    el.autocomplete({
                        source: function(request, response) {
                            var xx = request.term;
                           
                            if (xx !== '') {
                                $.ajax({
                                    url: "<?php echo base_url() . 'index.php/Welcome/GetSearchData' ?>",
                                    dataType: "json",
                                    method: 'post',
                                    data: {
                                        name_startsWith: request.term,
                                        type: 'layouts',
                                        row_num: 1
                                    },
                                    success: function(data) {
                                            
                                        response($.map(data, function(item) {
                                            var code = item.split("|");
                                          
                                            return {
                                                label: code[0],
                                                value: code[0],
                                                data: code[1]
                                            }
                                        }));
                                        var getid = el.attr('id');
                                        $(".ui-autocomplete").css("z-index", "9999999999");
                                    }
                                });
                            } else
                            {
                                $("#ui-id-1").css("display", "none");
                            }
                        },
                        	autoFocus: true,
                        	minLength: 0,
                        	select: function(event, ui) {
                            var ID = ui.item.data.split("|");
                            myFunction(ID);
                        }
                    });
                });
                
              
           
            
            
           function myFunction(id) {
                user_id = id;
               // var sdata = $("#countryname_1").val();
 				//window.location = "http://localhost/NewSocialUtilities/index.php/Searchresult?searchdata="+sdata;
                window.location="http://localhost/NewSocialUtilities/index.php/Welcome/Singlepage?random="+user_id;
//window.location="http://whitecode.in/demo/social_utilities/index.php/Welcome/Singlepage?random="+user_id;   
            }
  
    
          	});

var name_bit = 0;
        var email_bit = 0;
        var pass_bit = 0;
        var mno_bit = 0;
        $(document).ready(function() {



//This Ajax Use for new User Ragisterd
            $("#register_button").click(function(e) {
            	
                if (email_bit == 1 && mno_bit == 1) {
                    $.ajax({
                        url: '<?php echo base_url() . "index.php/Welcome/register_database"; ?>',
                        type: "POST",
                        data: $('#register_form').serialize(),
                        cache: false,
                        beforeSend: function()
                        {
                        },
                        success: function(response) {
                        	 $("#register_form")[0].reset(); 
                             $("#msg").html(response);
                             location.reload();
                        }
                    })
                } else {
                    document.getElementById('msg').innerHTML = "Please Enter your details";
                }
                e.preventDefault();
            }); //on click form submit
//END New User Ragister

//This Ajax Used For User Login
		$("#loginpass").keypress(function (e){
                if (e.keyCode == 13) {
                	 var wrong = "Your account not activated. check your mail and activate your account.";
                var check = "Wrong credentials";
                var check2="Please Enter All Fields";
                $.ajax({
                    url: '<?php echo base_url() . "index.php/Welcome/login_check"; ?>',
                    type: "POST",
                    data: $('#login_form').serialize(),
                    cache: false,
                    beforeSend: function()
                    {
                    },
                    success: function(response) {
                     $("#login_form")[0].reset(); 
                       alert(response);
                        if (response == 0) {
                            $("#msg1").html(wrong);
                        } else if (response == 2) {
                            $("#msg1").html(check);
                        }
                        else if (response == 1) {
                            window.location = "http://localhost/NewSocialUtilities/";
                        	//window.location = "http://whitecode.in/demo/social_utilities/";
                        }
                         else if(response == -1){
							$("#msg1").html(check2);
						}
                    }
                });
                 e.preventDefault();
                }
              });
                
            $("#login_button").click(function() {
            	
                var wrong = "Your account not activated. check your mail and activate your account.";
                var check = "Wrong credentials";
                var check2="Please Enter All Fields";
                $.ajax({
                    url: '<?php echo base_url() . "index.php/Welcome/login_check"; ?>',
                    type: "POST",
                    data: $('#login_form').serialize(),
                    cache: false,
                    beforeSend: function()
                    {
                    },
                    success: function(response) {
 $("#login_form")[0].reset(); 
                       alert(response);
                        if (response == 0) {
                            $("#msg1").html(wrong);
                        } else if (response == 2) {
                            $("#msg1").html(check);
                        }
                        else if (response == 1) {
                            window.location = "http://localhost/NewSocialUtilities/";
                        	//window.location = "http://whitecode.in/demo/social_utilities/";
                        }
                         else if(response == -1){
							$("#msg1").html(check2);
						}
                    }
                });
            }); //on click form submit
//END OF Login
      
  //code for forgot passward  
     $("#forgot_password_button").click(function(e) {
            
            var email = document.getElementById("fpemailid").value;
            var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
            if(email==''){
				 document.getElementById('msg2').innerHTML = "Enter email address" 
			}else if (emailReg.test(email) == false) {
               email_bit = 0;
                document.getElementById('msg2').innerHTML = "Invalid email address"
                return false;
               
            }else if (emailReg.test(email) == true) {
                email_bit = 1;
                 document.getElementById('msg2').innerHTML = ""
                
            }

       
                $.ajax({
                    url: '<?php echo base_url() . "index.php/Welcome/forgot_pass_check"; ?>',
                    type: "POST",
                    data: $('#forgot_pass_form').serialize(),
                    cache: false,
                    beforeSend: function()
                    {
                    	
                    },
                    success: function(response) {
                                               $("#forgot_pass_form")[0].reset(); 
						alert(response);  
						 
						 if(response==1){ 
						 				//alert("sdfsf"); 
						 				// e.preventDefault();     
						 				// return true;
						 				//window.location.href;
						 				
						 }else  if(response==0){
						 			 	document.getElementById('msg2').innerHTML = "Please Enter Your Email Id";
						 			 	// e.preventDefault();     
						 				// return false;
						 			 	
               			 }else  if(response==2){
						 			 	document.getElementById('msg2').innerHTML = "You are not an registered user please register.";
               			 }
                               
                    }
                
                });
            //on click form submit
//END OF Forgot Password   
  
        });
        
        
        
        
        
        
   });       
        
   function countChar1(val) {
   			var textbox = document.getElementById("rname").value;
           
            if (textbox.length < 2) {
                name_bit = 0;
                 document.getElementById('msg').innerHTML =  "Enter characters of minimum length 3"
              //   document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
            //     document.getElementById('mno').disabled = true;
            //     document.getElementById('uemail').disabled = true;
             //    document.getElementById('pass').disabled = true;
            } else {
            	 
                 document.getElementById('msg').innerHTML = ""
                 document.getElementById('msgpop').innerHTML =  ""
           //      document.getElementById('mno').disabled = false;
           //      document.getElementById('uemail').disabled = false;
           //      document.getElementById('pass').disabled = false;
                 name_bit = 1;
            }
            
             val = (val) ? val : window.event;
            var charCode = (val.which) ? val.which : val.keyCode;
              if((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 122)||(charCode === 8)||(charCode=== 32)||(charCode===39)){
              	
                return true;
            }
            return false;
        }

       
        function countmobile(evt) {
            var textbox = document.getElementById("mno").value;
            if (textbox.length < 9) {

                document.getElementById('msg').innerHTML = "Enter a 10 digit Phone no."
             //   document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
             ////    document.getElementById('rname').disabled = true;
              //  document.getElementById('uemail').disabled = true;
              //  document.getElementById('pass').disabled = true;
                //  document.getElementById('cpass').disabled = true;
                mno_bit = 0;
            } else if (textbox.length > 10) {
                document.getElementById('msg').innerHTML = "Enter a 10 digit Phone no."
                //document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
              //   document.getElementById('rname').disabled = true;
             //   document.getElementById('uemail').disabled = true;
             //   document.getElementById('pass').disabled = true;
                // document.getElementById('cpass').disabled = true;
                mno_bit = 0;
            } else {
                document.getElementById('msg').innerHTML = ""
                document.getElementById('msgpop').innerHTML =  ""
              //  document.getElementById('rname').disabled = false;
             //   document.getElementById('uemail').disabled = false;
             //   document.getElementById('pass').disabled = false;
                mno_bit = 1;
            }

            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }



		 

        function validateEmail() {
            var email = document.getElementById("uemail").value;
           var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,3})?$/;
            if (emailReg.test(email) == false) {
                email_bit = 0;
                document.getElementById('msg').innerHTML = "Invalid email address"
               // document.getElementById('msgpop').innerHTML =  "First Enter Current field then u can switch to another one"
               // document.getElementById('rname').disabled = true;
               // document.getElementById('mno').disabled = true;
               // document.getElementById('pass').disabled = true;
            } else {
                 email_bit = 1;
                 document.getElementById('msg').innerHTML = ""
                 document.getElementById('msgpop').innerHTML =  ""
                // document.getElementById('rname').disabled = false;
                // document.getElementById('mno').disabled = false;
                 //document.getElementById('pass').disabled = false;
            }

        }


        function checkPwd(val) {

            var str = document.getElementById("pass").value;
            
            if ((str.length < 4)) {
                document.getElementById('msg').innerHTML = "Password must have min 4 character "
                pass_bit = 1;
           
            }else{
				 document.getElementById('msg').innerHTML = ""
                pass_bit = 0;
			}
                
        }



    </script>
    <script>

        var curImages = new Array();
        function findUrls(text)
        {
            $('.' + text).trigger('keyup');
        }
        function findUrls1(text, id)
        {
            $('.' + text).liveUrl({
                loadStart: function() {
                },
                loadEnd: function() {
                },
                success: function(data)
                {
                    var output = $('.liveurl' + id);
                    output.find('.title' + id).text(data.title);
                    output.find('.description' + id).text(data.description);
                    var URL = '<a href="' + data.url + '" target="_blank">' + data.url + '</a>'
                    output.find('.url' + id).html(URL);
                    output.find('.image' + id).empty();
                    output.show('fast');



                },
                addImage: function(image)
                {
                    var output = $('.liveurl' + id);
                    var jqImage = $(image);
                    var newimage = jqImage.attr('src');
                    output.find('.image' + id).attr('src', newimage);
                    $('.appendnew').imagesLoaded(function() {
                        $("#gallery").preloader();
                        $('.appendnew').masonry();
                    });
                }
            });
        }
    </script>
  
               
    </body>
</html>