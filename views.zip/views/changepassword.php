<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title>Social Utility | Change Password</title>
        <meta name="generator" content="Bootply" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        
        
         <link href=<?php echo base_url("//code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" ); ?>  rel="stylesheet" />
        
	    <link href=<?php echo base_url("css/bootstrap.min.css"); ?> rel='stylesheet' type='text/css' />
        <link href=<?php echo base_url("css/4-col-portfolio.css"); ?> rel='stylesheet' type='text/css' />
        <!--[if lt IE 9]>
                <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <link href=<?php echo base_url("css/styles.css"); ?> rel='stylesheet' type='text/css' />
        <link href=<?php echo base_url("css/liveurl.css"); ?> rel='stylesheet' type='text/css' />
		
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
 <link href=<?php echo base_url("css/toastr.css"); ?> rel='stylesheet' type='text/css' />
<link href=<?php echo base_url("css/hover.css"); ?> rel='stylesheet' type='text/css' />
<script type="text/javascript" src=<?php echo base_url("js/jquery.min.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/jquery-ui.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/jquery.js");?>></script>
<script type="text/javascript" src=<?php echo base_url("js/toastr.js"); ?>></script>


<link href=<?php echo base_url("tooltipstyles.css"); ?> rel='stylesheet' type='text/css' />
<link href=<?php echo base_url("css/jquery-ui.min.css"); ?> rel='stylesheet' type='text/css' />

<style>
.popover{
    width:200px;
    height:250px;  
}</style> 

<script>
$(document).ready(function(){
				//toastr.success('Are you the six fingered man?', 'Inigo Montoya');
				//var priority = 'danger';
             //   var title = '';
             //   var message = 'Email is used but not activated. For activation check your email.';
             //   $.toaster({ priority: priority, title: title, message: message });
});	
</script>

 </head>
    <body>
   

             <?php include("header.html"); ?>
             <h4 class="modal-title" style="height: 30px;
    padding-left: 110px;
    font-size: 44px;
    font-weight: 700;
    text-align: center;
    text-decoration: none;
    text-shadow: 3px 1px #d9edf7;
    border-radius: 2px;
    color: rgb(53, 140, 234);
    margin: 20px 27px -38px -45px;">Change Password</h4>  
    
    
    
   
             <div class="col-md-4"></div>  
              
            <div class="column col-md-4" >
              
                <div class="padding">       
                   
                    
               
                    
                   
               

                <div class="account-form">
                
                
						<form id="forgot_pass_form" method="post">
						<center>
						 <ul >
                            <li >
                           <div style="padding-left:8px;">
										<input type="password"  id="password" class="input-text" name="pass"  value="<?php  $pass = $profile['password']; echo $pass?>" readonly>
							</div>	
							</li><br/>
							 <li > 
							  <div style="padding-left:8px;">
										<input type="password"  id="cpassword" class="input-text" name="cfpass"  placeholder="Enter New Password"><br>
								</div>	
							</li>	<br/>
							 <li >
							  <div style="padding-left:8px;">
                            			
                              </div>	
                            </li>
                        
							 <li > 		
							   <div >
										 <button class="btn btn-info hvr-sweep-to-right" id="change_password_button" type="submit" ><span>Submit</span></button>
								 </div>	
							</li>
						</ul>	
						  <span class="msg"></span>
						</center>			
						</form>
					</div>	
				 </div> 
           </div> 
          <div class="col-md-4"></div>   
        


    <!-- script references -->
<!--    <script src=<?php //echo base_url("js/jquery-1.7.js");                            ?>></script>-->
<!--    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>-->
     <script type="text/javascript" src=<?php echo base_url("js/jquery.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/bootstrap.min.js"); ?>></script> 
    <script type="text/javascript" src=<?php echo base_url("js/jquery-1.10.2.min.js"); ?>></script>
        <script type="text/javascript" src=<?php echo base_url('js/jquery-ui.min.js'); ?>></script>
  <!--  <script type="text/javascript" src=<?php echo base_url("js/jquery.masonry.js"); ?>></script>   -->
    <script type="text/javascript" src=<?php echo base_url("js/jquery.preloader.min.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/jquery.form.min.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/scripts.js"); ?>></script>
    <script type="text/javascript" src=<?php echo base_url("js/jquery.liveurl.js"); ?>></script>
  
    <style>
        .preloader { background:url(<?php echo base_url . "image/728.GIF" ?>) center center no-repeat #ffffff;  }
        
        
    </style>
 
 <script>
  $(document).ready(function() {
               
 	$("#searchbtn").click(function(){
 		var sdata = $("#countryname_1").val();
 		if(sdata == ""){
						 toastr.warning( 'Enter Search Data');
    						return false;
		}
		else{
			   // window.location = "http://localhost/NewSocialUtilities/index.php/Searchresult?searchdata="+sdata;
                        window.location="http://whitecode.in/demo/social_utilities/index.php/Searchresult?searchdata="+sdata;   
		}
 		
						
        });    
  });	
 	
 </script>
 
  <script>
              
            var  Dadicatorname = null;
            var  user_id=0;
            var  Dadicator_email_id = null;
            var  Dadicateename = null;
            var  Dadicatee_email_id = null;
            var  Dedication_title = null;
            var  Dedication_City = null;
                 
            $(document).ready(function() {
               
                $("#countryname_1").each(function(i, el) {
                    el = $(el);
                    el.autocomplete({
                        source: function(request, response) {
                            var xx = request.term;
                           
                            if (xx !== '') {
                                $.ajax({
                                    url: "<?php echo base_url() . 'index.php/Welcome/GetSearchData' ?>",
                                    dataType: "json",
                                    method: 'post',
                                    data: {
                                        name_startsWith: request.term,
                                        type: 'layouts',
                                        row_num: 1
                                    },
                                    success: function(data) {
                                            
                                        response($.map(data, function(item) {
                                            var code = item.split("|");
                                          
                                            return {
                                                label: code[0],
                                                value: code[0],
                                                data: code[1]
                                            }
                                        }));
                                        var getid = el.attr('id');
                                        $(".ui-autocomplete").css("z-index", "9999999999");
                                    }
                                });
                            } else
                            {
                                $("#ui-id-1").css("display", "none");
                            }
                        },
                        	autoFocus: true,
                        	minLength: 0,
                        	select: function(event, ui) {
                            var ID = ui.item.data.split("|");
                            myFunction(ID);
                        }
                    });
                });
                
              
            });
            
            
           function myFunction(id) {
                user_id = id;
               // var sdata = $("#countryname_1").val();
 				//window.location = "http://localhost/NewSocialUtilities/index.php/Searchresult?searchdata="+sdata;
                 window.location="http://localhost/NewSocialUtilities/index.php/Welcome/Singlepage?random="+user_id;
                // window.location="http://whitecode.in/demo/social_utilities/index.php/Welcome/Singlepage?random="+user_id;   
            }

</script>
    

 
     <script>
 	$(document).ready(function() {
               
 	$("#searchbtn").click(function(){
 		var sdata = $("#countryname_1").val();
 		if(sdata == ""){
						 toastr.warning( 'Enter Search Data');
    						return false;
		}
		else{
			 window.location = "http://localhost/NewSocialUtilities/index.php/Searchresult?searchdata="+sdata;
                  //         window.location="http://whitecode.in/demo/social_utilities/index.php/Searchresult?searchdata="+sdata;   
		}
 		
						
        });    
  });	
 	
 </script>
 <script>
       $(document).ready(function(){
       	
		var myValue = ' <?php print_r($uid);?>';
		//alert(myValue);
       	
          		$("#change_password_button").click(function(e){
          			
          			var pass=$("#pass").val();
          			var cpass=$("#cpassword").val();
          			
          			var id= myValue;
          			
          			//alert("aaaa");
          			
					//var Obj ={"cpass": cpass, "email":email};
					//var Data = 'Data='+JSON.stringify(obj);
          			//alert("Data");
          			
          			//if(pass){
						if(cpass){
							
						
          			
          			 $.ajax({
          			 	url: '<?php echo base_url() . "index.php/Changepass/reset_pass"; ?>',
          			    type: "POST",
                   		data: {
                				'id':id,
                				'cpass':cpass
                			  },
                		cache: false,
                		 beforeSend: function()
                        {
                        	//alert("heyyyyy");
                        },
                		success: function(response) {
                			 $("#forgot_pass_form")[0].reset(); 
                			if(response == "1"){
						    //toastr.success("Password changed Successfully");
    
                           $('.msg').html('<h3 style="text-align: center;display: block;  height: 30px; padding-left: 110px; font-size: 24px;font-weight: 700;  text-align: center; text-decoration: none;text-shadow: 3px 1px #d9edf7;  border-radius: 2px;  color: rgb(53, 140, 234);  margin: 20px 27px -38px -45px;">Password changed successfully Go to Login</h3>');
										
						window.location="http://localhost/NewSocialUtilities/index.php/Logout"
                                        //       window.location="http://whitecode.in/demo/social_utilities/index.php/Logout"       
							}else if(response == "0"){
										alert("Somthing Went Wrong");
							}
                		}
          				
          			})
          			}else{
								toastr.warning( 'Enter New Password');
    				 			return false;
					}
					//}else{
					//			toastr.warning( 'Enter Old Password');
    				 	//		return false;
					//}	
			 e.preventDefault();
          			
          		});
          		
          	});
 
</script>
  
</body>
</html>