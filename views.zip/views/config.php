<?php
include_once("inc/facebook.php"); //include facebook SDK
######### Facebook API Configuration ##########


$appId = '891978440912957'; //Facebook App ID
$appSecret = 'd4e4c95d7b27de4d7db78ead9fd63a23'; // Facebook App Secret
$homeurl = 'http://localhost/facebook_login_with_php/';  //return to home
$fbPermissions = 'email';  //Required facebook permissions

//Call Facebook API
$facebook = new Facebook(array(
  'appId'  => $appId,
  'secret' => $appSecret

));
$fbuser = $facebook->getUser();
?>